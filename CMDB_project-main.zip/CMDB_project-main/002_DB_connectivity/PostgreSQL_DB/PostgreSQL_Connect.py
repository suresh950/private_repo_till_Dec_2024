"""
this script will show the connectivity to PostgreSQL Server
"""
import psycopg2
import psycopg2.extras

hostname = "100.64.99.252"
dbname = "proddb"
username = "postgres"
password = "password"
port_id = "5432"

try:
    conn = psycopg2.connect(host = hostname,
                            dbname = dbname,
                            user=username,
                            password=password,
                            port = port_id)
    print("Connection PostgreSQL Successful")
except Exception as error:
    print(error)
finally:
    conn.close()