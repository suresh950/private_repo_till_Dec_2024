"""
this script will Insert new data to new row
"""
import psycopg2
import psycopg2.extras

hostname = "100.64.99.252"
dbname = "proddb"
username = "postgres"
password = "password"
port_id = "5432"

try:
    conn = psycopg2.connect(host = hostname,
                            dbname = dbname,
                            user=username,
                            password=password,
                            port = port_id)
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    insert_script = 'INSERT INTO emp (mac, ip_address, location, serial_number) VALUES (%s, %s, %s, %s)'
    insert_val = [
        ("aaaa.bbbb.aaaa", "192.168.10.1", "IND", "10JKHKJDSKJH01"),
        ("aaaa.bbbb.bbbb", "192.168.10.2", "KWT", "10JKHKJDSKJH02"),
        ("aaaa.bbbb.cccc", "192.168.10.3", "DXB", "10JKHKJDSKJH03"),
        ("aaaa.bbbb.dddd", "192.168.10.4", "OMN", "10JKHKJDSKJH04"),
        ("aaaa.bbbb.eeee", "192.168.10.5", "KSA_CP", "10JKHKJDSKJH05"),
        ("aaaa.bbbb.ffff", "192.168.10.6", "QTR", "10JKHKJDSKJH06")
    ]
    for val in insert_val:
        cur.execute(insert_script,val)

    conn.commit()
except Exception as error:
    print(error)
finally:
    cur.close()
    conn.close()