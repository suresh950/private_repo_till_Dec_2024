"""
this script will create new table anb put NEW data to a NEW Table.
"""

import psycopg2
import psycopg2.extras

hostname = "100.64.99.252"
dbname = "proddb"
username = "postgres"
password = "password"
port_id = "5432"

try:
    conn = psycopg2.connect(host = hostname,
                            dbname = dbname,
                            user=username,
                            password=password,
                            port = port_id)
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)

    cur.execute('DROP TABLE IF EXISTS emp') # this will delete the table and replace new table with the same name
    # Creating the TABLE using multiline comment,
    # where columns are defined as "mac", "ip_address", "location", "serial_number"
    create_script = '''CREATE TABLE IF NOT EXISTS emp
    (
    "mac" varchar(100) PRIMARY KEY,
    "ip_address" varchar(100) NOT NULL,
    "location" varchar(100),
    "serial_number" varchar(100)
    )
    '''
    # This is to insert new DATA in the same column in new row
    insert_script = 'INSERT INTO emp (mac, ip_address, location, serial_number) VALUES (%s, %s, %s, %s)'
    # Because of this VALUES( % s, %s, %s, %s) we can keep the data in tuple as given below
    insert_val = [
        ("aaaa.bbbb.0011", "192.168.1.11", "IND", "JKHKJDSKJH01"),
        ("aaaa.bbbb.0111", "192.168.1.111", "IND", "JKHKJDSKJH01"),
    ]

    cur.execute(create_script) # This is to create new column in tables

    for val in insert_val:
        cur.execute(insert_script,val) # this is to PUT the data in each column

    cur.execute('SELECT * FROM emp') # TO GET THE DATA
    for record in cur.fetchall():
        print(record["location"],record["ip_address"],record["mac"], record["serial_number"])

    conn.commit() # To save the data
except Exception as error:
    print(error)
finally:
    cur.close()
    conn.close()