"""
this script will GET data from a table.
"""
import psycopg2
import psycopg2.extras

hostname = "100.64.99.252"
dbname = "proddb"
username = "postgres"
password = "password"
port_id = "5432"

try:
    conn = psycopg2.connect(host = hostname,
                            dbname = dbname,
                            user=username,
                            password=password,
                            port = port_id)
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    cur.execute('SELECT * FROM emp') # This Command will get all the data available in the emp Table
    all_data = cur.fetchall()
    for data in all_data:
        print(data)
        print(data["location"], data["ip_address"], data["mac"], data["serial_number"])

except Exception as error:
    print(error)
finally:
    cur.close()
    conn.close()