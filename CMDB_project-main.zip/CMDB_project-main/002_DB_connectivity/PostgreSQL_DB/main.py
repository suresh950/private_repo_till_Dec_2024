import psycopg2
import psycopg2.extras

hostname = "100.64.99.252"
dbname = "proddb"
username = "postgres"
password = "password"
port_id = "5432"

try:
    conn = psycopg2.connect(host = hostname,
                            dbname = dbname,
                            user=username,
                            password=password,
                            port = port_id)
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)

    cur.execute('DROP TABLE IF EXISTS emp') # this will delete the table and replace new table with the same name
    create_script = '''CREATE TABLE IF NOT EXISTS emp
    (
    "mac" varchar(100) PRIMARY KEY,
    "ip_address" varchar(100) NOT NULL,
    "location" varchar(100),
    "serial_number" varchar(100)
    )
    '''
    insert_script = 'INSERT INTO emp (mac, ip_address, location, serial_number) VALUES (%s, %s, %s, %s)'
    insert_val = [
        ("aaaa.bbbb.0001", "192.168.1.1", "IND", "JKHKJDSKJH01"),
        ("aaaa.bbbb.0002", "192.168.1.2", "KWT", "JKHKJDSKJH02"),
        ("aaaa.bbbb.0003", "192.168.1.3", "DXB", "JKHKJDSKJH03"),
        ("aaaa.bbbb.0004", "192.168.1.4", "OMN", "JKHKJDSKJH04"),
        ("aaaa.bbbb.0005", "192.168.1.5", "KSA_CP", "JKHKJDSKJH05"),
        ("aaaa.bbbb.0006", "192.168.1.6", "QTR", "JKHKJDSKJH06")
    ]
    cur.execute(create_script)
    for val in insert_val:
        cur.execute(insert_script,val)
    cur.execute('SELECT * FROM emp')
    for record in cur.fetchall():
        print(record["location"],record["ip_address"],record["mac"], record["serial_number"])


    conn.commit()
    cur.close()
    conn.close()
except Exception as error:
    print(error)