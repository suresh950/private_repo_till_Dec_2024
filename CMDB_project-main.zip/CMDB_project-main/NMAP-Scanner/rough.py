import nmap

scanner = nmap.PortScanner()

ip = "192.168.126.116"

scanner.scan(ip, "0-1024",'-v -sS')
print(scanner.scaninfo())
print("IP status : ",scanner[ip].state())
print(scanner[ip].all_protocols())
print("OPEN PORTs ",scanner[ip]['tcp'].keys())


scanner.scan(ip, "0-1024",'-v -sU')
print(scanner.scaninfo())
print("IP status : ",scanner[ip].state())
print(scanner[ip].all_protocols())
print("OPEN PORTs ",scanner[ip]['udp'].keys())


scanner.scan(ip, "0-1024",'-v -sS -sV -sC -A -O')
print(scanner.scaninfo())
print("IP status : ",scanner[ip].state())
print(scanner[ip].all_protocols())
print("OPEN PORTs ",scanner[ip]['tcp'].keys())