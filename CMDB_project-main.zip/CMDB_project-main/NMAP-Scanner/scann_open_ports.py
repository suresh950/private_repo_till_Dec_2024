# import nmap
#
# scanner = nmap.PortScanner()
#
# ip = "172.16.98.20"
#
# scanner.scan(ip, "0-3999",'-v -sS')
# print(scanner.scaninfo())
# # print("IP status : ",scanner[ip].state())
# # print(scanner[ip].all_protocols())
# print("OPEN PORTs ",scanner[ip]['tcp'].keys())


# scanner.scan(ip, "0-1024",'-v -sU')
# print(scanner.scaninfo())
# print("IP status : ",scanner[ip].state())
# print(scanner[ip].all_protocols())
# print("OPEN PORTs ",scanner[ip]['udp'].keys())
#
#
# scanner.scan(ip, "0-1024",'-v -sS -sV -sC -A -O')
# print(scanner.scaninfo())
# print("IP status : ",scanner[ip].state())
# print(scanner[ip].all_protocols())
# print("OPEN PORTs ",scanner[ip]['tcp'].keys())

from pprint import pprint
import nmap

scanner = nmap.PortScanner()

ip = "172.16.98.20"

output = scanner.scan(ip, "0-1034",'-v -sS -sV -sC -A -O -Pn')
pprint(output)
print(scanner.scaninfo())
# print("IP status : ",scanner[ip].state())
# print(scanner[ip].all_protocols())
# print("OPEN PORTs ",scanner[ip]['tcp'].keys())