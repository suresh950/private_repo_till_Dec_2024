import nmap
from pprint import pprint
# scanner = nmap.PortScanner()
# #
# ip = "10.172.191.17"

# scanner.scan(ip, "0-1024",'-v -sS -sV -sC -A -O')
scanner  = {'addresses': {'ipv4': '10.172.191.17'},
 'hostnames': [{'name': '', 'type': ''}],
 'osmatch': [{'accuracy': '99',
              'line': '63348',
              'name': 'Linux 3.10 - 3.12',
              'osclass': [{'accuracy': '99',
                           'cpe': ['cpe:/o:linux:linux_kernel:3'],
                           'osfamily': 'Linux',
                           'osgen': '3.X',
                           'type': 'general purpose',
                           'vendor': 'Linux'}]},
             {'accuracy': '99',
              'line': '63634',
              'name': 'Linux 3.11 - 4.1',
              'osclass': [{'accuracy': '99',
                           'cpe': ['cpe:/o:linux:linux_kernel:3'],
                           'osfamily': 'Linux',
                           'osgen': '3.X',
                           'type': 'general purpose',
                           'vendor': 'Linux'},
                          {'accuracy': '99',
                           'cpe': ['cpe:/o:linux:linux_kernel:4'],
                           'osfamily': 'Linux',
                           'osgen': '4.X',
                           'type': 'general purpose',
                           'vendor': 'Linux'}]},
             {'accuracy': '99',
              'line': '64343',
              'name': 'Linux 3.16',
              'osclass': [{'accuracy': '99',
                           'cpe': ['cpe:/o:linux:linux_kernel:3.16'],
                           'osfamily': 'Linux',
                           'osgen': '3.X',
                           'type': 'general purpose',
                           'vendor': 'Linux'}]},
             {'accuracy': '99',
              'line': '67452',
              'name': 'Linux 4.4',
              'osclass': [{'accuracy': '99',
                           'cpe': ['cpe:/o:linux:linux_kernel:4.4'],
                           'osfamily': 'Linux',
                           'osgen': '4.X',
                           'type': 'general purpose',
                           'vendor': 'Linux'}]},
             {'accuracy': '99',
              'line': '67981',
              'name': 'Linux 4.9',
              'osclass': [{'accuracy': '99',
                           'cpe': ['cpe:/o:linux:linux_kernel:4.9'],
                           'osfamily': 'Linux',
                           'osgen': '4.X',
                           'type': 'general purpose',
                           'vendor': 'Linux'}]},
             {'accuracy': '99',
              'line': '64492',
              'name': 'Linux 3.18',
              'osclass': [{'accuracy': '99',
                           'cpe': ['cpe:/o:linux:linux_kernel:3.18'],
                           'osfamily': 'Linux',
                           'osgen': '3.X',
                           'type': 'general purpose',
                           'vendor': 'Linux'}]},
             {'accuracy': '98',
              'line': '13201',
              'name': 'Check Point UTM-1 Edge X firewall',
              'osclass': [{'accuracy': '98',
                           'cpe': [],
                           'osfamily': 'embedded',
                           'osgen': None,
                           'type': 'firewall',
                           'vendor': 'Check Point'}]},
             {'accuracy': '98',
              'line': '19822',
              'name': 'D-Link DSL-2890AL ADSL router',
              'osclass': [{'accuracy': '98',
                           'cpe': ['cpe:/h:dlink:dsl-2890al'],
                           'osfamily': 'embedded',
                           'osgen': None,
                           'type': 'broadband router',
                           'vendor': 'D-Link'}]},
             {'accuracy': '98',
              'line': '23403',
              'name': 'Draytek Vigor 2960 VPN firewall',
              'osclass': [{'accuracy': '98',
                           'cpe': ['cpe:/h:draytek:vigor_2960'],
                           'osfamily': 'embedded',
                           'osgen': None,
                           'type': 'security-misc',
                           'vendor': 'Draytek'}]},
             {'accuracy': '98',
              'line': '30967',
              'name': 'Android 2.3.7 (Linux 2.6.37)',
              'osclass': [{'accuracy': '98',
                           'cpe': ['cpe:/o:google:android:2.3.7'],
                           'osfamily': 'Android',
                           'osgen': '2.X',
                           'type': 'phone',
                           'vendor': 'Google'},
                          {'accuracy': '98',
                           'cpe': ['cpe:/o:linux:linux_kernel:2.6',
                                   'cpe:/o:google:android:2'],
                           'osfamily': 'Linux',
                           'osgen': '2.6.X',
                           'type': 'phone',
                           'vendor': 'Linux'}]}],
 'portused': [{'portid': '22', 'proto': 'tcp', 'state': 'open'},
              {'portid': '1', 'proto': 'tcp', 'state': 'closed'},
              {'portid': '30524', 'proto': 'udp', 'state': 'closed'}],
 'status': {'reason': 'echo-reply', 'state': 'up'},
 'tcp': {22: {'conf': '10',
              'cpe': 'cpe:/o:linux:linux_kernel',
              'extrainfo': 'protocol 2.0',
              'name': 'ssh',
              'product': 'OpenSSH',
              'reason': 'syn-ack',
              'script': {'ssh-hostkey': '\n'
                                        '  2048 '
                                        '2c:69:30:b7:37:12:15:fa:50:eb:39:eb:c9:47:6a:62 '
                                        '(RSA)\n'
                                        '  256 '
                                        'd4:4b:71:e0:6b:64:b1:17:29:70:d8:73:53:92:ed:20 '
                                        '(ECDSA)\n'
                                        '  384 '
                                        '60:af:54:51:ac:c2:58:36:f6:9a:af:7b:a9:07:c4:5b '
                                        '(ECDSA)\n'
                                        '  521 '
                                        'f3:f0:21:bc:18:45:c4:98:24:88:72:2c:ec:47:22:77 '
                                        '(ECDSA)'},
              'state': 'open',
              'version': '7.4p1 Debian 10+deb9u7'},
         636: {'conf': '3',
               'cpe': '',
               'extrainfo': '',
               'name': 'ldapssl',
               'product': '',
               'reason': 'syn-ack',
               'script': {'ssl-cert': 'Subject: commonName=StoneGate firewall '
                                      'node/organizationName=Forcepoint\n'
                                      'Subject Alternative Name: DNS:51514\n'
                                      'Issuer: commonName=SG Root CA '
                                      '(76fd8ad8069a9000)\n'
                                      'Public Key type: rsa\n'
                                      'Public Key bits: 2048\n'
                                      'Signature Algorithm: '
                                      'sha256WithRSAEncryption\n'
                                      'Not valid before: 2021-04-21T12:29:23\n'
                                      'Not valid after:  2024-04-20T12:29:23\n'
                                      'MD5:   '
                                      '67e0:08b2:38d8:8f75:23a3:5117:2bab:6545\n'
                                      'SHA-1: '
                                      '3eb7:55fa:f781:5637:a05b:422d:d7e6:ebfa:6ab0:a3c7',
                          'ssl-date': 'TLS randomness does not represent time'},
               'state': 'open',
               'version': ''}},
 'uptime': {'lastboot': 'Mon Dec  4 00:19:04 2023', 'seconds': '3155617'},
 'vendor': {}}
# scanner replace with scanner[ip]
# for data in scanner[ip].items():
raw_data = {"hostnames" : scanner["hostnames"][0]["name"],
            "addresses": scanner["addresses"]["ipv4"],
            "status": scanner["status"]["state"],
            "osmatch": scanner["osmatch"][0]["osclass"][0]["osfamily"],
            }
#
#     print(data)
print(raw_data)