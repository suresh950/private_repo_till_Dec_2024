"""
This code will give the below output
Note: On the cisco device it is scanning correctly and it is giving the right Software Version and OS Platform
IP status:
Hardware Type:
Software Version:
OS Platform:
Time taken in scan :
"""
import nmap
from datetime import datetime
scanner = nmap.PortScanner()
# ip = "10.29.24.149" # Windows Laptop
# ip = "172.16.98.20" # windows VM
# ip = "10.29.1.11" # cisco device
# ip = "10.29.4.35" # Cisco AP
ip = "10.208.111.109" #Firewall
# ip = "10.33.90.4" # Extream IP
timenow1 = datetime.now()

scanner.scan(ip, "0-1024", '-v -sS -sV -sC -A -O') # Aggressive scann
if scanner[ip].state() == "up":
    print("IP status: Up")
    try:
        hardware_type = scanner[ip]['osclass'][0]['osfamily'] # Extract hardware type, software version, and OS platform
    except:
        hardware_type = "Unknown"
    try:
        software_version = scanner[ip]['osmatch'][0]['osclass'][0]['cpe'][0]
    except:
        software_version = "Unknown"
    try:
        os_platform = scanner[ip]['osmatch'][0]['osclass'][0]['osfamily']
    except:
        os_platform = "Unknown"
    # print("IP address :", ip)

    print("Hardware Type:", hardware_type)
    print("Software Version:", software_version)
    print("OS Platform:", os_platform)
else:
    print("IP status: Down")
timenow2 = datetime.now()

time_difference = timenow2 - timenow1
print("Time taken in scan : ",time_difference)