import nmap

def host_discovery(target):
    nm = nmap.
    nm.scan(target)

    # Access the results
    for host, result in nm.all_hosts().items():
        print(f"Host: {host}")
        print(f"Status: {result['status']['state']}")
        print("-----------------------")

# Example usage
target_to_scan = "172.16.200.130"  # You can specify a range or a single IP address
host_discovery(target_to_scan)
