import nmap
from datetime import datetime
import os
import sys
from ping3 import ping
class ALScann:
    def __init__(self):
        self.SMC_API_URL = os.environ["SMC_API_URL"]
        self.API_KEY = os.environ["SMC_READ_API_KEY"]
    def get_os_platform(self,host):
        try:
            # Perform a single ping to check if the host is reachable
            output_data = {}
            response = ping(host)
            if response is not None:
                # print(f"Host {host} is UP")
                scanner = nmap.PortScanner()
                scanner.scan(host, "0-1024", '-v -sS -sV -sC -A -O')  # Aggressive scann
                try:
                    os_platform = scanner[host]['osmatch'][0]['osclass'][0]['osfamily']
                    output_data = {"Host": ["UP"],
                                   "os_platform": [f"{os_platform}"]}
                    return output_data
                except:
                    output_data = {"Host": ["UP"],
                                   "os_platform": ["Unknown"]}
                    return output_data
            else:
                output_data = {"Host":["Down"],
                               "os_platform":["N/A"]}
                return output_data

        except:
            output_data = {"Host": ["Error"],
                           "os_platform": ["Error"]}
            return output_data



