import nmap
from nmap_cust_class import *
scanner = nmap.PortScanner()
#
ip = "172.16.100.50"
scann = ALScann()
print(scann.get_os_platform(ip))
