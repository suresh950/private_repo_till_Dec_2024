import nmap3
nmap = nmap3.Nmap()

version_result = nmap.nmap_version_detection("100.64.99.99")
print(version_result)
"""  this is the result 
{'100.64.99.99': {'osmatch': {}, 'ports': [{'protocol': 'tcp', 'portid': '21', 'state': 'filtered', 
'reason': 'no-response', 'reason_ttl': '0', 'service': {'name': 'ftp', 'method': 'table', 'conf': '3'}, 
'cpe': [], 'scripts': []}, {'protocol': 'tcp', 'portid': '22', 'state': 'filtered', 'reason': 'no-response', 
'reason_ttl': '0', 'service': {'name': 'ssh', 'method': 'table', 'conf': '3'}, 'cpe': [], 'scripts': []}, 
{'protocol': 'tcp', 'portid': '23', 'state': 'filtered', 'reason': 'no-response', 'reason_ttl': '0', 'service': 
{'name': 'telnet', 'method': 'table', 'conf': '3'}, 'cpe': [], 'scripts': []}, 
{'protocol': 'tcp', 'portid': '53', 'state': 'open', 'reason': 'syn-ack', 'reason_ttl': '30', 
.'service': {'name': 'domain', 'product': 'Unbound', 'method': 'probed', 'conf': '10'}, 
'cpe': [{'cpe': 'cpe:/a:nlnetlabs:unbound'}], 'scripts': []}, 
{'protocol': 'tcp', 'portid': '80', 'state': 'open', 'reason': 'syn-ack', 'reason_ttl': '30', 'service': 
{'name': 'http', 'product': 'ZyXEL Virtual Web httpd', 'version': '0.9', 'devicetype': 'WAP', 'method': 'probed', 
'conf': '10'}, 'cpe': [], 'scripts': []}, {'protocol': 'tcp', 'portid': '443', 'state': 'open', 'reason': 'syn-ack', 
'reason_ttl': '30', 'service': {'name': 'https', 'tunnel': 'ssl', 'method': 'table', 'conf': '3'}, 'cpe': [], 
'scripts': []}, {'protocol': 'tcp', 'portid': '5431', 'state': 'filtered', 'reason': 'no-response', 
'reason_ttl': '0', 'service': {'name': 'park-agent', 'method': 'table', 'conf': '3'}, 'cpe': [], 'scripts': []}], 
'hostname': [], 'macaddress': {'addr': 'B8:C1:AC:90:23:1D', 'addrtype': 'mac'}, 
'state': {'state': 'up', 'reason': 'arp-response', 'reason_ttl': '0'}}, 
'runtime': {'time': '1704620767', 'timestr': 'Sun Jan  7 15:16:07 2024', 
'summary': 'Nmap done at Sun Jan  7 15:16:07 2024; 1 IP address (1 host up) scanned in 37.01 seconds', 
'elapsed': '37.01', 'exit': 'success'}, 'stats': {'scanner': 'nmap', 
'args': '"C:/Program Files (x86)/Nmap/nmap.exe" -v -oX - -sV 100.64.99.99', 'start': '1704620730', 'startstr': 
'Sun Jan  7 15:15:30 2024', 'version': '7.94', 'xmloutputversion': '1.05'}, 'task_results': [{'task': 'ARP Ping Scan', 
'time': '1704620731', 'extrainfo': '1 total hosts'}, {'task': 'Parallel DNS resolution of 1 host.', 'time': '1704620742'}, 
{'task': 'SYN Stealth Scan', 'time': '1704620744', 'extrainfo': '1000 total ports'}, {'task': 'Service scan', 
'time': '1704620750', 'extrainfo': '3 services on 1 host'}, {'task': 'NSE', 'time': '1704620759'}, 
{'task': 'NSE', 'time': '1704620767'}]}
"""
os_results = nmap.nmap_os_detection("100.64.99.99") # MOST BE ROOT
print(os_results)

"""
getting error on this 
{'error': True, 'msg': 'You must be root/administrator to continue!'}
"""
