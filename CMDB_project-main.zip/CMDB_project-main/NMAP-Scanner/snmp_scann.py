"""


"""
import nmap
from datetime import datetime
class NMAP_scann:
    def __init__(self):
        pass

    def snmp_scann(self,ip):
        scanner = nmap.PortScanner()
        scanner.scan(ip, "0-1024", '-v -sS -sV -sC -A -O')  # Aggressive scann
        if scanner[ip].state() == "up":
            print("IP status: Up")


scanner = nmap.PortScanner()
