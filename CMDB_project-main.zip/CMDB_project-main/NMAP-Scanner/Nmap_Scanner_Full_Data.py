import nmap
from pprint import pprint
scanner = nmap.PortScanner()
#
# ip = "10.29.24.149" # Windows Laptop
# ip = "172.16.98.20" # windows VM
# ip = "10.29.1.11" # cisco device
# ip = "172.16.200.130" # linux machine
# ip = "10.48.62.12" # Cisco AP
# ip = "10.29.4.35" # Cisco AP
# ip = "" # Linux Machine
# ip = "10.168.60.6" #Legacy AP
ip = input("please Enter the IP address: = ")

ports_to_Scann = ("0-1024, 1025, 1194, 1337, 1589, 1725, 2082, 2083, 2483, 2484, 2967, 3074, 3306, 3724, 4664,"
                          "5432, 5900, 6665-6669, 6881, 6999, 6970, 8086, 8087, 8222, 9100, 10000, 12345, 27374, 31337")

scanner.scan(ip, ports_to_Scann, '-v -sS -sV -sC -O')  # Aggressive scann

os_platform = scanner[ip]['osmatch'][0]['osclass'][0]['osfamily']
print(os_platform)
pprint(scanner[ip])

# for data in scanner[ip].items():
# raw_data = {"hostnames" : scanner[ip]["hostnames"][0]["name"],
#             "addresses": scanner[ip]["addresses"]["ipv4"],
#             "status": scanner[ip]["status"]["state"],
#             }
#
#     print(data)
# print(raw_data)

