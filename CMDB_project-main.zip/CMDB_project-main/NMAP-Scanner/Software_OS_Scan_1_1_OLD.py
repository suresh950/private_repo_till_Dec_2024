"""
This code will give the below output
Note: On the cisco device it is scanning correctly and it is giving the right Software Version and OS Platform
IP status:
Hardware Type:
Software Version:
OS Platform:
Time taken in scan :
"""
import nmap
from datetime import datetime
scanner = nmap.PortScanner()
ip = "10.209.26.202"
timenow1 = datetime.now()

scanner.scan(ip, "0-1024", '-v -sS -sV -sC -A -O')
if scanner[ip].state() == "up":
    print("IP status: Up")
    try:
        hardware_type = scanner[ip]['osclass'][0]['osfamily'] # Extract hardware type, software version, and OS platform
    except KeyError:
        hardware_type = "Unknown"
    try:
        software_version = scanner[ip]['osmatch'][0]['osclass'][0]['cpe'][0]
    except KeyError:
        software_version = "Unknown"
    try:
        os_platform = scanner[ip]['osmatch'][0]['osclass'][0]['osfamily']
    except KeyError:
        os_platform = "Unknown"
    print("Hardware Type:", hardware_type)
    print("Software Version:", software_version)
    print("OS Platform:", os_platform)
else:
    print("IP status: Down")
timenow2 = datetime.now()

time_difference = timenow2 - timenow1
print("Time taken in scan : ",time_difference)