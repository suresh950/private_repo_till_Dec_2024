""" This is function will ssh to the single firewall and return the output
list of Forcepoint command user in the script
cmd = [f"echo {password} | sudo -S dmidecode | grep -A6 0x0003 | tail -1",
       f"echo {password} | sudo -S ip a",
       f"echo {password} | sudo -S sg-dmidata",
       f"echo {password} | sudo -S sg-version"]
Note --> New_file1.xlsx is hard coded you must provide the file name in "existing_file' variable
"""
import os
import time
import re
import pandas as pd
import paramiko

class SSH_ngfw:
    # global corresponding_value_in_column_name,desired_value_in_column_ip,firmware_mac
    corresponding_value_in_column_name = None
    desired_value_in_column_ip = None
    firmware_mac = None
    fw_serial_number = None
    fw_pol =  None
    fw_model = None
    firmware_version = None

    def __int__(self):
        pass
    def SSH_fw(self, ngfw_ip):
        """ This function will execute the code and will display the output on output screen """
        """ Creating ssh client instanciate """
        username = os.environ["ngfwusername"]
        password = os.environ["ngfwpass"]
        commands = [f"echo {password} | sudo -S dmidecode | grep -A6 0x0003 | tail -1",
                       f"echo {password} | sudo -S sg-status -l",
                       f"echo {password} | sudo -S sg-dmidata",
                       f"echo {password} | sudo -S sg-version"]
#
        serial_number = re.compile(r'(Serial Number: )(.+)')
        product_name = re.compile(r'(Product Name: )(.+)')
        pol = re.compile(r'(STONE-ID: )(.+)')
        ver = re.compile(r'(NGFW version )(.+)')
        mac = re.compile(r'(Interface 1).+(\S\S:\S\S:\S\S:\S\S:\S\S:\S\S)')

        try:
            connection_timeout = 10
            ssh_client = paramiko.client.SSHClient()
            ssh_client.set_missing_host_key_policy(paramiko.client.AutoAddPolicy())
            ssh_client.connect(hostname=ngfw_ip, username=username,
                               password=password, port=22,
                               look_for_keys=False,
                               allow_agent=False,
                               timeout=connection_timeout)
            print(f"Connecting to {ngfw_ip}")
            """ Sending the command to cisco device """
            connect = ssh_client.invoke_shell()
            for command in commands:
                connect.send(f"{command} \n".encode("utf-8"))

            time.sleep(5)
            connect.settimeout(10)
            output = connect.recv(9899)
            connect.close()
            fw_output = output.decode()
            """
            Regex section (regular expression)
            """
            output_serial_number = serial_number.search(string=fw_output)
            output_model = product_name.search(string=fw_output)
            output_pol = pol.search(string=fw_output)
            output_ver = ver.search(string=fw_output)
            output_mac = mac.search(string=fw_output)

            fw_serial_number = output_serial_number.group(2)
            fw_model = output_model.group(2)
            fw_pol = output_pol.group(2)
            firmware_version = output_ver.group(2)
            firmware_mac = output_mac.group(2)
            """
            Raw data to dict 
            New_file1.xlsx is hard coded you must provide the file name in "existing_file'
            """
            existing_file = 'output_files/New_file1.xlsx'
            df = pd.read_excel(existing_file)
            desired_value_in_column_ip = f"{ngfw_ip}"
            corresponding_value_in_column_name = df.loc[
                df['Node1_IP'] == desired_value_in_column_ip, 'Firewall_name'].values
            if len(corresponding_value_in_column_name) != 0:
                corresponding_value_in_column_name = df.loc[
                    df['Node1_IP'] == desired_value_in_column_ip, 'Firewall_name'].values
            else:
                corresponding_value_in_column_name = df.loc[
                    df['Node2_IP'] == desired_value_in_column_ip, 'Firewall_name'].values

        except Exception as TimeoutError:
            corresponding_value_in_column_name[0] = ""
            desired_value_in_column_ip = ""
            firmware_mac = ""
            fw_serial_number = ""
            fw_pol = ""
            fw_model = ""
            firmware_version = ""

        except:
            print(f"Unable to login to the Firewall")

        firewall_raw_dict = {"Firewall_name": [f"{corresponding_value_in_column_name[0]}"],
                             "LAN_IP": [f"{desired_value_in_column_ip}"],
                             "LAN_MAC": [f"{firmware_mac}"],
                             "SN": [f"{fw_serial_number}"],
                             "POL": [f"{fw_pol}"],
                             "Model_number": [f"{fw_model}"],
                             "firmware_version": [f"{firmware_version}"]}
        for key, value_list in firewall_raw_dict.items():
            firewall_raw_dict[key] = [value.rstrip('\r') for value in value_list]

        print(firewall_raw_dict)

        existing_file_OUTPUT = "output_files/ngfw_data.xlsx"
        existing_df = pd.read_excel(existing_file_OUTPUT, sheet_name="ngfw-data")
        df_updated = pd.concat([existing_df, pd.DataFrame(firewall_raw_dict)], ignore_index=True)
        df_updated.to_excel(existing_file_OUTPUT, index=False, sheet_name='ngfw-data')
        return firewall_raw_dict