from snmp_cmdb.snmp_cust_class import *
from CMDB_pingsweep.cmdb_pingsweep import *
import nmap
from datetime import datetime
class CMDB_scann:
    def __init__(self):
        pass
    def scann(self,ip):
        scanner = nmap.PortScanner()
        scanner.scan(ip, "0-1024", '-v -sS -sV -sC -O')  # Aggressive scann
        if scanner[ip].state() == "up":
            print("IP status: Up")
            check_if_it_is_fw = SNMP_fw_Class()
            try:
                os_platform = scanner[ip]['osmatch'][0]['osclass'][0]['osfamily']
                print(os_platform)
            except:
                OS_PLATFORM = "Unknown"
            if os_platform == "Windows":
                OS_PLATFORM = "Windows"
            elif os_platform == "IOS":
                OS_PLATFORM = "Cisco_IOS"
            else:
                try:
                    print("i am here")
                    n = check_if_it_is_fw.snmp_get(ip)
                    OS_PLATFORM = f"{n}" # do not change this formate f"{n}
                    print(OS_PLATFORM)
                    if OS_PLATFORM == "False":
                        print("i am in iff")

                except:
                    print("not able to find the OS version")
        else:
            print("IP status: Down")

        raw_dect = {"Device_IP": [ip],
                    "Device_status": ["UP"],
                    "os_platform": [OS_PLATFORM]}
        print(raw_dect)


time_start = datetime.now()
#================== testing section ===================
test = CMDB_scann()
# ip = "10.29.24.149" # Windows Laptop
# ip = "172.16.98.20" # windows VM
# ip = "10.29.1.11" # cisco device
# ip = "10.29.4.35" # Cisco AP
ip = "172.16.200.130" # Linux Machine
# ip = "172.16.200.130"#"10.208.111.109" # Firewall
# ip = "10.33.90.4" # Extreme IP 10.32.89.17

test.scann(ip)
time_end = datetime.now()
total_time = time_end - time_start
print(total_time)