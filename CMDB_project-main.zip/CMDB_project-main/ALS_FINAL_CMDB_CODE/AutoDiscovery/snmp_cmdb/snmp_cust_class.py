"""
This code is using below OID to get the Firewall Type
OIDs TO Use
    '1.3.6.1.2.1.1.1.0',  # sysDescr
"""
from pysnmp.hlapi import *
class SNMP_fw_Class:
    def __int__(self):
        pass
    def snmp_get(self,host):
        community_string = 'Shaya20L8'
        snmp_port = 161
        oid = '1.3.6.1.2.1.1.1.0'
        error_indication, error_status, error_index, var_binds = next(
            getCmd(SnmpEngine(),
                   CommunityData(community_string),
                   UdpTransportTarget((host, snmp_port)),
                   ContextData(),
                   ObjectType(ObjectIdentity(oid)))
        )

        if error_indication:
            return False
        elif error_status:
            return False
        else:
            for var_bind in var_binds:
                return var_bind[1]
