import statistics
import pandas as pd
from snmp_cmdb.snmp_cust_class import *
# from CMDB_pingsweep.cmdb_pingsweep import *
import nmap
from datetime import datetime
class CMDB_scann:
    def __init__(self):
        pass
    def scann(self,ip):
        start_time = datetime.now()
        scanner = nmap.PortScanner()
        ports_to_Scann = ("0-1024, 1025, 1194, 1337, 1589, 1725, 2082, 2083, 2483, 2484, 2967, 3074, 3306,3389, 3724, 4664,"
                          "5432, 5900, 6665-6669, 6881, 6999, 6970, 8086, 8087, 8222, 9100, 10000, 12345, 27374, 31337")
          # Aggressive scann
        scanner.scan(ip, ports_to_Scann, '-v -sS -sV -sC -O')
        if scanner[ip].state() == "up":
            # print("IP status: Up")
            device_state="UP"
            open_port_list = []
            try:
                open_port_output = scanner[ip]['tcp'].keys()
                for port in open_port_output:
                    open_port_list.append(port)
            except:
                open_port_list = "None"
            check_if_it_is_fw = SNMP_fw_Class()
            try:
                states_reason = scanner[ip]['status']['reason']
                # accuracy = scanner[ip]['osmatch'][0]['accuracy']
                os_platform = scanner[ip]['osmatch'][0]['osclass'][0]['osfamily']
                raw_osmatch_list = scanner[ip]['osmatch']
            except:
                OS_PLATFORM = "Unknown"
            # if accuracy == "100":
            #     OS_PLATFORM = f'{os_platform} 100 '
            if os_platform == "IOS":
                OS_PLATFORM = "IOS"
            elif os_platform == "Windows":
                OS_PLATFORM = "Windows"
            elif os_platform == "TMOS":
                OS_PLATFORM = "F5-BIG-IP"
            else:
                try:
                    predicted_OS_list = []
                    for raw_os in raw_osmatch_list:
                        os_data = raw_os['osclass'][0]['osfamily']
                        predicted_OS_list.append(os_data)
                    most_common_OS = statistics.mode(predicted_OS_list)
                    if most_common_OS =='Linux':
                        try:
                            n = check_if_it_is_fw.snmp_get(ip)
                            Fw_OS_PLATFORM = f"{n}" # do not change this formate f"{n}
                            if Fw_OS_PLATFORM =='Forcepoint NGFW Firewall/VPN':
                                OS_PLATFORM = Fw_OS_PLATFORM
                            else:
                                OS_PLATFORM = "Linux"
                        except:
                            OS_PLATFORM = "Linux"
                    elif most_common_OS =='RAIDiator':
                        OS_PLATFORM = "Linux"
                    elif most_common_OS =="embedded":
                        OS_PLATFORM = "Linux"
                    elif most_common_OS =="OpenBSD":
                        OS_PLATFORM = "Solaris"
                    else:
                        OS_PLATFORM = f" N/A may Be it is {most_common_OS}"
                except:
                    OS_PLATFORM = "N/A"
                    print("unable to find the OS_PLATFORM")
        else:
            pass

        end_time = datetime.now()
        scan_time = end_time - start_time
        raw_dct = {"Device_IP": [ip],
                    "Device_status": [device_state],
                    "status_reason": [states_reason],
                    "OPEN_PORTS": [open_port_list],
                    "os_platform": [OS_PLATFORM],
                    "Time": [f"{scan_time}"]
                    # "most_common_OS_prediction_BY_NMAP": most_common_OS
                    }
        try:
            output_file = "output_files/scann_files/raw_output/scann_output.xlsx"
            df = pd.read_excel(output_file, sheet_name="Sheet1")
            df_updated = pd.concat([df, pd.DataFrame(raw_dct)], ignore_index=True)
            df_updated.to_excel(output_file, index=False, sheet_name='Sheet1')
        except Exception as a :
            print(a)

        print(raw_dct)
