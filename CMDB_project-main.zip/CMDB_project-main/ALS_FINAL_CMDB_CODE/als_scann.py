"""
Note:
   1. cmdb_ipaddress is folder --> cmdb_ipaddress_cust_class.py  --> Class (CMDB_ipaddress) -->
--> Function (input_ip_list) input_ip_list function provides ip list of provided ip segment as input
"""
import pandas as pd
import ipaddress
import concurrent.futures
from cmdb_scann.cmdb_scann import *
#
# INPUT_FILE = "output_files/scann_files/ip_list.xlsx"
# df = pd.read_excel(INPUT_FILE,sheet_name="Linux_VM")
# ip_list = df['ip'].tolist()

network_segment = input("Please enter the IP segment: ")
def ip_list(network_segment):
    ip_list = []
    try:
        network = ipaddress.IPv4Network(network_segment, strict=False)
        for ip in network.hosts():
            ip_list.append(str(ip))
    except ValueError as e:
        print(f"Error: {e}")
    return ip_list

ip_list = ip_list(network_segment)

cmdb_scann = CMDB_scann()

with concurrent.futures.ThreadPoolExecutor() as executor:
    futures = []
    for ip in ip_list:
        # print(ip)
        executor.submit(cmdb_scann.scann, ip)