from snmp_cust_class import SNMP_fw_Class
from pysnmp.hlapi import *

test = SNMP_fw_Class()
host = "10.173.39.145"
print(test.snmp_get(host))