"""
OIDs TO Use
    '1.3.6.1.2.1.1.1.0',  # sysDescr
    '1.3.6.1.2.1.1.5.0',  # sysName
    '1.3.6.1.2.1.1.6.0',  # sysLocation
    '1.3.6.1.2.1.1.4.0',  # sysContact
    '1.3.6.1.2.1.2.2.1.2.1',  # ifDescr for interface 1
    '1.3.6.1.2.1.2.2.1.8.1',  # ifOperStatus for interface 1
    '1.3.6.1.2.1.2.2.1.10.1',  # ifInOctets for interface 1
    '1.3.6.1.2.1.2.2.1.16.1'  # ifOutOctets for interface 1
"""

from pysnmp.hlapi import *

# SNMP parameters
target_ip = '172.16.98.20'
community_string = 'Shaya20L8'
snmp_port = 161

# SNMP get operation
def snmp_get(oid):
    error_indication, error_status, error_index, var_binds = next(
        getCmd(SnmpEngine(),
               CommunityData(community_string),
               UdpTransportTarget((target_ip, snmp_port)),
               ContextData(),
               ObjectType(ObjectIdentity(oid)))
    )

    if error_indication:
        print(f"Error: {error_indication}")
    elif error_status:
        print(f"Error: {error_status.prettyPrint()}")
    else:
        for var_bind in var_binds:
            print(f"{var_bind[0]} = {var_bind[1]}")

# Function to print system details
def print_system_details():
    oids = [
        '1.3.6.1.2.1.1.1.0',  # sysDescr
    '1.3.6.1.2.1.1.5.0',  # sysName
    '1.3.6.1.2.1.1.6.0',  # sysLocation
    '1.3.6.1.2.1.1.4.0',  # sysContact
    '1.3.6.1.2.1.2.2.1.2.1',  # ifDescr for interface 1
    '1.3.6.1.2.1.2.2.1.8.1',  # ifOperStatus for interface 1
    '1.3.6.1.2.1.2.2.1.10.1',  # ifInOctets for interface 1
    '1.3.6.1.2.1.2.2.1.16.1'  # ifOutOctets for interface 1
    ]
    for oid in oids:
        snmp_get(oid)

# Example: Print system details
print_system_details()
