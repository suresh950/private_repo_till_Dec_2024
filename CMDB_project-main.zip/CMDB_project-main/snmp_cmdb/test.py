import nmap3
def get_mac_address(target_ip):
    nm = nmap3.Nmap()
    result = nm.scan_top_ports(target_ip)

    if target_ip in result:
        host_info = result[target_ip]
        if 'addresses' in host_info and 'mac' in host_info['addresses']:
            mac_address = host_info['addresses']['mac']
            print(f"MAC address of {target_ip}: {mac_address}")
        else:
            print(f"No MAC address found for {target_ip}")
    else:
        print(f"Scan failed for {target_ip}")

if __name__ == "__main__":
    target_ip = input("Enter the IP address of the remote device: ")
    get_mac_address(target_ip)


