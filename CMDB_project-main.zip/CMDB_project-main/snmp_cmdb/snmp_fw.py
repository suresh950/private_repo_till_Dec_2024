"""
This code is using below OID to get the Firewall Type
OIDs TO Use
    '1.3.6.1.2.1.1.1.0',  # sysDescr

"""
from pysnmp.hlapi import *

def snmp_get(host):
    community_string = 'Shaya20L8'
    snmp_port = 161
    oid = '1.3.6.1.2.1.1.1.0'
    error_indication, error_status, error_index, var_binds = next(
        getCmd(SnmpEngine(),
               CommunityData(community_string),
               UdpTransportTarget((host, snmp_port)),
               ContextData(),
               ObjectType(ObjectIdentity(oid)))
    )

    if error_indication:
        return error_indication
    elif error_status:
        return error_status.prettyPrint()
    else:
        for var_bind in var_binds:
            return var_bind[1]



target_ip = '10.173.39.145'
print(snmp_get(host=target_ip))
