import nmap

def get_mac_address(ip_address):
    scanner = nmap.PortScanner()
    scanner.scan(ip_address, arguments='-O')

    # Check if the host is up
    if ip_address in scanner.all_hosts():
        mac_address = scanner[ip_address]['addresses']['mac']
        print(f"MAC Address of {ip_address}: {mac_address}")
    else:
        print(f"Host {ip_address} is not responding.")

# Replace 'your_target_ip' with the IP address you want to scan
get_mac_address('100.64.99.99')
