import nmap


def get_mac_address(ip_address):
    scanner = nmap.PortScanner()

    try:
        scanner.scan(ip_address, arguments='-O -PR -v')

        if ip_address in scanner.all_hosts():
            mac_address = scanner[ip_address]['addresses']['mac']
            print(f"MAC Address of {ip_address}: {mac_address}")
        else:
            print(f"Host {ip_address} is not responding.")
    except Exception as e:
        print(f"Error scanning {ip_address}: {str(e)}")


# Replace 'your_target_ip' with the IP address you want to scan
get_mac_address('your_target_ip')
