import nmap
import concurrent.futures
import pandas as pd
from datetime import datetime
from pprint import pprint
time_start = datetime.now()
def tcp_scann(ip):
    scanner = nmap.PortScanner()
    scanner.scan(ip, "0-3999",'-v -sS -sV -sC -A -O -Pn')
    # scanner.scan(ip, "0-1024",'-T4 -F')
    output = scanner[ip]['tcp'].keys()
    # ip_state = scanner[ip].state()
    open_port_list = []
    for port in output:
        open_port_list.append(port)
    raw_dict = {"ip_address": [f"{ip}"],
                "open_ports": [f"{open_port_list}"]}
    print(raw_dict)

    OUTPUT_FILE = "files/output1.xlsx"  # change
    final_output_df = pd.read_excel(OUTPUT_FILE, sheet_name="Sheet1")  # Change
    df_updated = pd.concat([final_output_df, pd.DataFrame(raw_dict)], ignore_index=True)
    df_updated.to_excel(OUTPUT_FILE, index=False, sheet_name='Sheet1')  # Change

input_file_path = "files/ip_list.xlsx"
input_df = pd.read_excel(input_file_path)
ip_list = input_df['ip_address'].tolist()
with concurrent.futures.ThreadPoolExecutor() as executor:
    futures = []
    for ip in ip_list:
        executor.submit(tcp_scann, ip)

time_end = datetime.now()
total_time = time_end - time_start

print(total_time)