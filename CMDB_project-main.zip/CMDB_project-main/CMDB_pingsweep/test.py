from datetime import datetime
import ipaddress
import threading
from ping3 import ping

def is_host_up(host):
    try:
        # Perform a single ping to check if the host is reachable
        response = ping(host, unit="ms")
        if response is not None:
            print(f"Host {host} is UP with response time={response}")
        else:
            print(f"Host {host} is DOWN")
    except Exception as e:
        print(f"Error: {e}")
        print(f"Failed to check the status of {host}")

def ping_hosts_in_range(network):
    threads = []
    for ip in network.hosts():
        thread = threading.Thread(target=is_host_up, args=(str(ip),))
        threads.append(thread)
        thread.start()

    # Wait for all threads to complete
    for thread in threads:
        thread.join()

if __name__ == "__main__":
    network_segment = input("Enter network segment (e.g., 192.168.1.0/24): ")
    start_time = datetime.now()

    try:
        network = ipaddress.IPv4Network(network_segment, strict=False)
        ping_hosts_in_range(network)
    except ValueError as e:
        print(f"Error: {e}")

    end_time = datetime.now()
    print(f"Time taken: {end_time - start_time}")
