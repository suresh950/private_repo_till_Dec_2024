import subprocess
import platform
import sys
from ping3 import ping, verbose_ping
def is_host_up(host):
    """
    Check if a host is up using a ping sweep.
    """
    try:
        # Perform a single ping to check if the host is reachable
        response = ping(host)

        if response is not None:
            print(f"Host {host} is UP")
        else:
            print(f"Host {host} is DOWN")
    except Exception as e:
        print(f"Error: {e}")
        print(f"Failed to check the status of {host}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python script.py <host>")
        sys.exit(1)

    host_to_check = sys.argv[1]
    is_host_up(host_to_check)
