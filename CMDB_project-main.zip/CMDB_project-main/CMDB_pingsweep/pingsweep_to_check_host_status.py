"""
Check if a host is up using a ping sweep.
"""
from ping3 import ping, verbose_ping
def is_host_up(host, num_pings=3):
    try:
        # Perform multiple pings to check if the host is reachable
        for _ in range(num_pings):
            response = ping(host, unit="ms")
            if response is not None:
                print(f"Host {host} is UP")
                return  # Exit the function if any single ping is successful
        # If none of the pings were successful
        print(f"Host {host} is DOWN")
    except Exception as e:
        print(f"Error: {e}")
        print(f"Failed to check the status of {host}")
# Example usage


