"""
Check if a host is up using a ping sweep.
"""
import ipaddress
from ping3 import ping, verbose_ping
def is_host_up(host):
    try:
        # Perform a single ping to check if the host is reachable
        response = ping(host, unit="ms")
        if response is not None:
            print(f"Host {host} is UP with response time={response}")
        else:
            print(f"Host {host} is DOWN")
    except Exception as e:
        print(f"Error: {e}")
        print(f"Failed to check the status of {host}")

is_host_up("172.16.98.20")
