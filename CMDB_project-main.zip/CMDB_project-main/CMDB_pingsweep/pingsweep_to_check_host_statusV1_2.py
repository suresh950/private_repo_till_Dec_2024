"""
Check if a host is up using a ping sweep.
"""
from datetime import datetime
import ipaddress
from ping3 import ping, verbose_ping
def is_host_up(host):
    try:
        # Perform a single ping to check if the host is reachable
        response = ping(host, unit="ms")
        if response is not None:
            print(f"Host {host} is UP with response time={response}")
        else:
            print(f"Host {host} is DOWN")
    except Exception as e:
        print(f"Error: {e}")
        print(f"Failed to check the status of {host}")

network_segment = input("Enter network segment (e.g., 192.168.1.0/24): ")
time = datetime.now()
try:
    network = ipaddress.IPv4Network(network_segment, strict=False)
    for ip in network.hosts():
        print(str(ip))
        is_host_up(str(ip))
except ValueError as e:
    print(f"Error: {e}")
print(f'This is start time ={time.strftime("%d-%m-%Y_%H-%M-%S")}\n')
time = datetime.now()
print(f'this is end time = {time.strftime("%d-%m-%Y_%H-%M-%S")}\n')