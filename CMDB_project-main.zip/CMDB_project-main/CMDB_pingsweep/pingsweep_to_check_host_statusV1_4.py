"""
Using Multithreading here
Check if a host is up using a ping sweep.
"""
import time
# from datetime import datetime
import ipaddress
import threading
from ping3 import ping, verbose_ping
def is_host_up(host):
    try:
        # Perform a single ping to check if the host is reachable
        response = ping(host, unit="ms")
        if response is not None:
            print(f"Host {host} is UP\n")
        else:
            print(f"Host {host} is DOWN\n")
    except Exception as e:
        print(f"Error: {e}")
        print(f"Failed to check the status of {host}")
network_segment = input("Enter network segment (e.g., 192.168.1.0/24): ")

try:
    network = ipaddress.IPv4Network(network_segment, strict=False)
    threads = []
    for ip in network.hosts():
        thread = threading.Thread(target=is_host_up, args=(str(ip)))
        threads.append(thread)
        thread.start()
    for thread in threads:
        thread.join()
except ValueError as e:
    print(f"Error:")
