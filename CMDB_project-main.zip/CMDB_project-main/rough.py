import time
from datetime import datetime
timenow = datetime.now()

time.sleep(10)

timenow2= datetime.now()
print(timenow2-timenow)