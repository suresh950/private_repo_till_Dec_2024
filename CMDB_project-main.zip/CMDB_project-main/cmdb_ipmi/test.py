from pyghmi.ipmi import command

# IPMI connection parameters
ip_address = 'your_ipmi_ip'
username = 'your_username'
password = 'your_password'

# Create an IPMI connection
ipmi = command.Command(username, password, ip_address)

# Get sensor data
sensor_data = ipmi.get_sensor_data()

# Print sensor data
for sensor in sensor_data:
    print(f"Sensor ID: {sensor['Sensor ID']}, Name: {sensor['Name']}, Value: {sensor['Sensor Reading']}, Status: {sensor['Status']}")

# Close the IPMI connection
ipmi = None
