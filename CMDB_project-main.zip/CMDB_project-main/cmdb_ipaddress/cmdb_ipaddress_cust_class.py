"""
this code prompts for network segment, and it gives all usable IP available in the segment
"""
import ipaddress
class CMDB_ipaddress:
    def __init__(self):
        self.network_segment = input("Enter network segment (e.g., 192.168.1.0/24): ")
    def input_ip_list(self):
        try:
            input_ip_list = []
            network = ipaddress.IPv4Network(self.network_segment, strict=False)
            for ip in network.hosts():
                input_ip_list.append(str(ip))
            return input_ip_list
        except ValueError as e:
            print(f"Error: {e}")