# from CMDB_SMC import *
import threading
import pandas as pd

import concurrent.futures
from  SSH_connect_ngfw_1_3_OLD import *
# connect = CustomSmcClass()
# existing_file = "output_files/file.xlsx"
# # connectngfw = Fpngfw()
# # dict_file = connectngfw.fw_db_renew(existing_file)
# connect.connect_to_smc()
# connect.refresh_fw_DB(existing_file)
# connect.close_connection()
# # print(dict_file)
# # print(dict_file["DXB-STR-SBX-MINISTRY-OF-PRESIDENTIAL-AFFAIRS-FW"])
# # for key in dict_file:
# #     print(key)
#

"""
connecting to firewall 
"""
# def test(ngfw_ip):
#        ssh_connection = SSH_ngfw()
#        output = ssh_connection.SSH_fw(ngfw_ip)
#        # print(output)
#

connect_to_firewall = SSH_ngfw()
# # ip_list = connect_to_firewall.firewall_ip
# ip_list = "10.21.40.1"
# output = connect_to_firewall.SSH_fw(ip_list)
# print(output)



# def your_function(ip):
#     # Your function implementation here
#     return {"IP": ip, "status": "success"}
# file_path = 'your_file.xlsx'
# df = pd.read_excel(file_path)
# column_2_values = df['column_2']
ip_list = ["10.144.3.101", "10.173.98.161", "10.21.51.225","10.175.171.10","10.144.3.165"]

with concurrent.futures.ThreadPoolExecutor() as executor:
    futures = []
    for ip in ip_list:
        future = executor.submit(connect_to_firewall.SSH_fw, ip)
        futures.append(future)
    # futures = [executor.submit(connect_to_firewall.SSH_fw, ip) for ip in ip_list]
result_dict_list = [future.result() for future in futures]
for result_dict in result_dict_list:
    print(result_dict)


# try:
#        threads = []
#        with concurrent.futures.ThreadPoolExecutor() as executor:
#               executor.map(connect_to_firewall.SSH_fw, ip_list)
# except ValueError as e:
#        print(f"Error: {e}")
#
# import pandas as pd
#
# # Replace 'your_file.xlsx' and 'Sheet1' with your actual file and sheet names
# file_path = 'output_files/file.xlsx'
# sheet_name = 'mySheet'
#
# # Replace 'Column_Name' with the actual column name you want to convert to a list
# column_name1 = 'Firewall_name'
# column_name2 = 'IP'
#
# # Read the Excel file
# df = pd.read_excel(file_path, sheet_name=sheet_name)
#
# # Extract the specified column into a list
# column_list1 = df[column_name1].tolist()
# column_list2 = df[column_name2].tolist()
#
# print(column_list1)
# print(column_list2)
