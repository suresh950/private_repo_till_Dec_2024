
import concurrent.futures
from SSH_connect_ngfw_1_3_OLD import *
"""
connecting to firewall 
"""

connect_to_firewall = SSH_ngfw()

ip_list = ["10.144.3.101", "10.173.98.161", "10.21.51.225","10.175.171.10","10.144.3.165"]

with concurrent.futures.ThreadPoolExecutor() as executor:
    futures = []
    for ip in ip_list:
        future = executor.submit(connect_to_firewall.SSH_fw, ip)
        futures.append(future)
    # futures = [executor.submit(connect_to_firewall.SSH_fw, ip) for ip in ip_list]
result_dict_list = [future.result() for future in futures]

for result_dict in result_dict_list:
    print(result_dict)


