"""
this code will write the data in xlsx sheet
"""
import concurrent.futures
from SSH_connect_ngfw import *
"""
connecting to firewall 
"""
existing_file_OUTPUT = "output_files/ngfw_data.xlsx"
connect_to_firewall = SSH_ngfw()
# Example firewall to test the SSH_connect_ngfw module.
input_file_path = "output_files/file.xlsx"
df = pd.read_excel(input_file_path)
db_fw_ip_list = df['IP'].tolist()
ip_list = ["10.144.3.101", "10.173.98.161", "10.21.51.225","10.175.171.10","10.144.3.165"]

with concurrent.futures.ThreadPoolExecutor() as executor:
    futures = []
    for ip in db_fw_ip_list:
        future = executor.submit(connect_to_firewall.SSH_fw, ip)
        futures.append(future)

result_dict_list = [future.result() for future in futures]

for result_dict in result_dict_list:
    existing_df = pd.read_excel(existing_file_OUTPUT, sheet_name="ngfw-data")
    df_updated = pd.concat([existing_df, pd.DataFrame(result_dict)], ignore_index=True)
    df_updated.to_excel(existing_file_OUTPUT, index=False, sheet_name='ngfw-data')
    print(result_dict)
