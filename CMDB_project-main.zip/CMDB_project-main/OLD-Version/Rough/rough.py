import pandas as pd

input_file_path = "../../output_files/New_file.xlsx" # SMC firewall DB Files
df10 = pd.read_excel(input_file_path) # dataframe from SMC DB
df20 = pd.read_excel(input_file_path, usecols=["Node2_IP"])
Node1_IP_fw_list = df10['Node1_IP'].tolist()
Node2_IP_fw_list = df20["Node2_IP"].dropna().tolist()
merged_list = Node1_IP_fw_list + Node2_IP_fw_list
print(merged_list)

