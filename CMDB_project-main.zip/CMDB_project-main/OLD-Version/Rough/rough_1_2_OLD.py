"""
1. created custom class CustomSmcClass which will contain the SMC related function.
2. connect_to_smc,close_connection --> these two function will make the connection and close the connection
3. we have one function "ngfw_name_and_IP" -->
"""
import csv
import os
import time
import smc
import time
from datetime import datetime
import paramiko
from smc.core.engines import Engine
import pandas as pd
import smc
import csv
# from smc.core.engines import Engine
from smc.core.engines import Layer3Firewall, Layer3PhysicalInterface, FirewallCluster
import os
import datetime

class CustomSmcClass:
    def __init__(self):
        self.SMC_API_URL = os.environ["SMC_API_URL"]
        # self.API_KEY ="mmoBEFZsCv5GsWWz6ulvBsrt"
        self.API_KEY = os.environ["SMC_READ_API_KEY"]
##################################################################################
    def connect_to_smc(self):
        smc.session.login(url=self.SMC_API_URL, api_key=self.API_KEY)  # --> Establishing connection to SMC
##################################################################################
    def close_connection(self):
        smc.session.logout()  # Closing the connection to SMC
##################################################################################

# engine = Engine.objects.all()
test = CustomSmcClass()
test.connect_to_smc()
engine = Engine("KWT-HO-DC")
snmp1 = engine.snmp_interface
print(snmp1[0]["address"])
print(snmp1[1]["address"])
for each1 in snmp1:
    print(each1.get("address"),each1.get("nicid"))

test.close_connection()