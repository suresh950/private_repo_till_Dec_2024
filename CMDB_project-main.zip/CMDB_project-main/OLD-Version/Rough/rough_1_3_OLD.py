import pandas as pd



try:
    existing_file = "output_files/test.xlsx"
    # Your code that may raise an exception
    n = int(input("Enter the value: "))
    result = 10 / n  # Example: division by zero
    firewall_dict = {"result": [result]}
    existing_df = pd.read_excel(existing_file, sheet_name="Sheet1")
    df_updated = pd.concat([existing_df, pd.DataFrame(firewall_dict)], ignore_index=True)
    df_updated.to_excel(existing_file, index=False, sheet_name='Sheet1')
except Exception as e:
    # Handle any type of exception
    existing_file1 = "output_files/test.xlsx"
    error_dict = {"error": [f"{e}"]}
    try:
        existing_df = pd.read_excel(existing_file1, sheet_name="Sheet2")
    except FileNotFoundError:
        existing_df = pd.DataFrame()  # Create an empty DataFrame if 'Sheet2' doesn't exist
    df_updated = pd.concat([existing_df, pd.DataFrame(error_dict)], ignore_index=True)
    df_updated.to_excel(existing_file1, index=False, sheet_name='Sheet2')
    print(f"An error occurred: {e}")

