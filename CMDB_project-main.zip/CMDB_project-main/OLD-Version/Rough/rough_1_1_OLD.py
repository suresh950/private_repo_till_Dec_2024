import concurrent.futures
from SSH_connect_ngfw import *
import pandas as pd
input_file_path = "output_files/file.xlsx"
input_fw_file_path = "output_files/ngfw_data.xlsx"
df = pd.read_excel(input_file_path) # dataframe from SMC DB
df2 = pd.read_excel(input_fw_file_path) # dataframe from firewall DB
smc_db_fw_list = df['IP'].tolist()
db_fw_list =df2['LAN_IP'].tolist()
def find_unique_fw_ip(smc_db_fw_list, db_fw_list):
    C = []  # List to store elements from A not present in B
    for element in smc_db_fw_list:
        if element not in db_fw_list:
            C.append(element)
    print(len(C))

find_unique_fw_ip(smc_db_fw_list=smc_db_fw_list,db_fw_list=db_fw_list)
