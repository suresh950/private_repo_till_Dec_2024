"""
1. created custom class CustomSmcClass which will contain the SMC related function.
2. connect_to_smc,close_connection --> these two function will make the connection and close the connection
3. we have one function "ngfw_name_and_IP" -->
"""
import csv
import os
import time
import smc
import time
from datetime import datetime
import paramiko
from smc.core.engines import Engine
import pandas as pd
import smc
import csv
# from smc.core.engines import Engine
from smc.core.engines import Layer3Firewall, Layer3PhysicalInterface, FirewallCluster
import os
import datetime

class CustomSmcClass:
    def __init__(self):
        self.SMC_API_URL = os.environ["SMC_API_URL"]
        # self.API_KEY ="mmoBEFZsCv5GsWWz6ulvBsrt"
        self.API_KEY = os.environ["SMC_READ_API_KEY"]
##################################################################################

    def connect_to_smc(self):
        smc.session.login(url=self.SMC_API_URL, api_key=self.API_KEY)  # --> Establishing connection to SMC
##################################################################################

    def close_connection(self):
        smc.session.logout()  # Closing the connection to SMC
##################################################################################

    def get_all_ngfw_name(self): # This function will give list of all the firewall name
        """ This function will give the all firewall name available in SMC
        ( provide the file name to store the data )"""
        ngfw_list = []
        engine = Engine.objects.all()   # getting into SMC
        for node in engine: # looping in the Engine all objects
            # print(node.name)         # taking down the name from the node
            new_row = node.name       # creating list of firewall name
            ngfw_list.append(new_row)
        return ngfw_list
################################### To get the firewall name IP and interface ###############################################
    def ngfw_name_and_IP(self,existing_file):
        engine = Engine.objects.all()
        for node in engine: # looping in the Engine all objects
            # each_node = node.nodes
            # print(each_node)
            firewall_name = node.name
            existing_df = pd.read_excel(existing_file, sheet_name="mySheet")
            try:
                into_firewall = Layer3Firewall.get(name=f"{firewall_name}") # getting into firewall
                to_get_snmp_interface = into_firewall.snmp.interface[0].name # Getting firewall interface name
                snmp_interface_id = to_get_snmp_interface.split()[1] # Getting firewall interface id
                ip_address_of_snmp_interface = into_firewall.interface.get(interface_id=snmp_interface_id).addresses # Getting firewall ip address of snmp interface
                snmp_ip = ip_address_of_snmp_interface[0][0]
                # new_row = [firewall_name, snmp_ip, to_get_snmp_interface] # Creating a list of details
                firewall_dict = {f"Firewall_name": [f"{firewall_name}"],
                                 "IP": [f"{snmp_ip}"],
                                 "Interface": [f"{to_get_snmp_interface}"]}
                df_updated = pd.concat([existing_df, pd.DataFrame(firewall_dict)], ignore_index=True)
                df_updated.to_excel(existing_file, index=False, sheet_name='mySheet')
                print(firewall_dict)

            except:
                # if above code fails then this will execute
                # or "may be the firewall name is wrong or firewall not present in SMC"
                try:
                    into_firewall = FirewallCluster.get(name=f"{firewall_name}")
                    to_get_snmp_interface = into_firewall.snmp.interface[0].name
                    snmp_interface_id = to_get_snmp_interface.split()[1] # Getting firewall interface id
                    ip_address_of_snmp_interface = into_firewall.interface.get(interface_id=snmp_interface_id).addresses # Getting firewall ip address of snmp interface
                    snmp_ip = ip_address_of_snmp_interface[0][0]
                    firewall_dict = {f"Firewall_name": [f"{firewall_name}"],
                                     "IP": [f"{snmp_ip}"],
                                     "Interface": [f"{to_get_snmp_interface}"]}
                    firewall_dict = {f"Firewall_name": [f"{firewall_name}"],
                                     "IP": [f"{snmp_ip}"],
                                     "Interface": [f"{to_get_snmp_interface}"]}
                    df_updated = pd.concat([existing_df, pd.DataFrame(firewall_dict)], ignore_index=True)
                    df_updated.to_excel(existing_file, index=False, sheet_name='mySheet')
                    print(firewall_dict)
                except:
                    print(f"not able to get the detail of {firewall_name}")
            # break

################################### To get the sigle firewall name IP and interface ###############################################
    def sigle_ngfw_name_and_IP(self,existing_file,firewall_name): # Provide firewall name to update the data
        existing_df = pd.read_excel(existing_file, sheet_name="mySheet")
        try:
            into_firewall = Layer3Firewall.get(name=f"{firewall_name}")  # getting into firewall
            to_get_snmp_interface = into_firewall.snmp.interface[0].name  # Getting firewall interface name
            snmp_interface_id = to_get_snmp_interface.split()[1]  # Getting firewall interface id
            ip_address_of_snmp_interface = into_firewall.interface.get(
                interface_id=snmp_interface_id).addresses  # Getting firewall ip address of snmp interface
            snmp_ip = ip_address_of_snmp_interface[0][0]
            # new_row = [firewall_name, snmp_ip, to_get_snmp_interface] # Creating a list of details
            firewall_dict = {f"Firewall_name": [f"{firewall_name}"],
                             "IP": [f"{snmp_ip}"],
                             "Interface": [f"{to_get_snmp_interface}"]}
            df_updated = pd.concat([existing_df, pd.DataFrame(firewall_dict)], ignore_index=True)
            df_updated.to_excel(existing_file, index=False, sheet_name='mySheet')
            print(firewall_dict)
        except:
            # if above code fails then this will execute
            # or "may be the firewall name is wrong or firewall not present in SMC"
            try:
                into_firewall = FirewallCluster.get(name=f"{firewall_name}")
                to_get_snmp_interface = into_firewall.snmp.interface[0].name
                snmp_interface_id = to_get_snmp_interface.split()[1]  # Getting firewall interface id
                ip_address_of_snmp_interface = into_firewall.interface.get(
                    interface_id=snmp_interface_id).addresses  # Getting firewall ip address of snmp interface
                snmp_ip = ip_address_of_snmp_interface[0][0]
                firewall_dict = {f"Firewall_name": [f"{firewall_name}"],
                                 "IP": [f"{snmp_ip}"],
                                 "Interface": [f"{to_get_snmp_interface}"]}
                df_updated = pd.concat([existing_df, pd.DataFrame(firewall_dict)], ignore_index=True)
                df_updated.to_excel(existing_file, index=False, sheet_name='mySheet')
                print(firewall_dict)
            except:
                print(f"not able to get the detail of {firewall_name}")
################################### Update the firewall Database ###############################################
    def update_fw_DB(self,existing_file,firewall_name):
        self.sigle_ngfw_name_and_IP(existing_file,firewall_name)

################################### Update the firewall Database #############################################


#======================== class test code ========================#.

