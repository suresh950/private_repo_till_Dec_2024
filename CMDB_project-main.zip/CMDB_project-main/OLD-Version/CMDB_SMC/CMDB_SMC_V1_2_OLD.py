"""
1. created custom class CustomSmcClass which will contain the SMC related function.
2. connect_to_smc,close_connection --> these two function will make the connection and close the connection
3. we have one function "ngfw_name_and_IP" -->
"""
import csv
import os
import time
import smc
import time
from datetime import datetime
import paramiko
from smc.core.engines import Engine
import pandas as pd
import smc
import csv
# from smc.core.engines import Engine
from smc.core.engines import Layer3Firewall, Layer3PhysicalInterface, FirewallCluster
import os
import datetime

class CustomSmcClass:
    def __init__(self):
        self.SMC_API_URL = os.environ["SMC_API_URL"]
        # self.API_KEY ="mmoBEFZsCv5GsWWz6ulvBsrt"
        self.API_KEY = os.environ["SMC_READ_API_KEY"]
##################################################################################
    def connect_to_smc(self):
        smc.session.login(url=self.SMC_API_URL, api_key=self.API_KEY)  # --> Establishing connection to SMC
##################################################################################
    def close_connection(self):
        smc.session.logout()  # Closing the connection to SMC
##################################################################################
    def get_all_ngfw_name(self): # This function will give list of all the firewall name
        """ This function will give the all firewall name available in SMC
        ( provide the file name to store the data )"""
        ngfw_list = []
        engine = Engine.objects.all()   # getting into SMC
        for node in engine: # looping in the Engine all objects
            # print(node.name)         # taking down the name from the node
            new_row = node.name       # creating list of firewall name
            ngfw_list.append(new_row)
        return ngfw_list
################################### To get the firewall name IP and interface ###############################################
    def ngfw_name_and_IP(self,existing_file):
        engine = Engine.objects.all()
        for node in engine: # looping in the Engine all objects
            # each_node = node.nodes
            # print(each_node)
            firewall_name = node.name
            existing_df = pd.read_excel(existing_file, sheet_name="mySheet")
            try:
                into_firewall = Layer3Firewall.get(name=f"{firewall_name}") # getting into firewall
                to_get_snmp_interface = into_firewall.snmp.interface[0].name # Getting firewall interface name
                snmp_interface_id = to_get_snmp_interface.split()[1] # Getting firewall interface id
                ip_address_of_snmp_interface = into_firewall.interface.get(interface_id=snmp_interface_id).addresses # Getting firewall ip address of snmp interface
                snmp_ip = ip_address_of_snmp_interface[0][0]
                # new_row = [firewall_name, snmp_ip, to_get_snmp_interface] # Creating a list of details
                firewall_dict = {f"Firewall_name": [f"{firewall_name}"],
                                 "IP": [f"{snmp_ip}"],
                                 "Interface": [f"{to_get_snmp_interface}"]}
                df_updated = pd.concat([existing_df, pd.DataFrame(firewall_dict)], ignore_index=True)
                df_updated.to_excel(existing_file, index=False, sheet_name='mySheet')
                print(firewall_dict)

            except:
                # if above code fails then this will execute
                # or "may be the firewall name is wrong or firewall not present in SMC"
                try:
                    into_firewall = FirewallCluster.get(name=f"{firewall_name}")
                    to_get_snmp_interface = into_firewall.snmp.interface[0].name
                    snmp_interface_id = to_get_snmp_interface.split()[1] # Getting firewall interface id
                    ip_address_of_snmp_interface = into_firewall.interface.get(interface_id=snmp_interface_id).addresses # Getting firewall ip address of snmp interface
                    snmp_ip = ip_address_of_snmp_interface[0][0]
                    firewall_dict = {f"Firewall_name": [f"{firewall_name}"],
                                     "IP": [f"{snmp_ip}"],
                                     "Interface": [f"{to_get_snmp_interface}"]}
                    firewall_dict = {f"Firewall_name": [f"{firewall_name}"],
                                     "IP": [f"{snmp_ip}"],
                                     "Interface": [f"{to_get_snmp_interface}"]}
                    df_updated = pd.concat([existing_df, pd.DataFrame(firewall_dict)], ignore_index=True)
                    df_updated.to_excel(existing_file, index=False, sheet_name='mySheet')
                    print(firewall_dict)
                except:
                    print(f"not able to get the detail of {firewall_name}")
            # break

################################### To get the sigle firewall name IP and interface ###############################################
    def sigle_ngfw_name_and_IP(self,existing_file,firewall_name): # Provide firewall name to update the data
        existing_df = pd.read_excel(existing_file, sheet_name="mySheet")
        try:
            into_firewall = Layer3Firewall.get(name=f"{firewall_name}")  # getting into firewall
            to_get_snmp_interface = into_firewall.snmp.interface[0].name  # Getting firewall interface name
            snmp_interface_id = to_get_snmp_interface.split()[1]  # Getting firewall interface id
            ip_address_of_snmp_interface = into_firewall.interface.get(
                interface_id=snmp_interface_id).addresses  # Getting firewall ip address of snmp interface
            snmp_ip = ip_address_of_snmp_interface[0][0]
            # new_row = [firewall_name, snmp_ip, to_get_snmp_interface] # Creating a list of details
            firewall_dict = {f"Firewall_name": [f"{firewall_name}"],
                             "IP": [f"{snmp_ip}"],
                             "Interface": [f"{to_get_snmp_interface}"]}
            df_updated = pd.concat([existing_df, pd.DataFrame(firewall_dict)], ignore_index=True)
            df_updated.to_excel(existing_file, index=False, sheet_name='mySheet')
            print(firewall_dict)
        except:
            # if above code fails then this will execute
            # or "may be the firewall name is wrong or firewall not present in SMC"
            try:
                into_firewall = FirewallCluster.get(name=f"{firewall_name}")
                to_get_snmp_interface = into_firewall.snmp.interface[0].name
                snmp_interface_id = to_get_snmp_interface.split()[1]  # Getting firewall interface id
                ip_address_of_snmp_interface = into_firewall.interface.get(
                    interface_id=snmp_interface_id).addresses  # Getting firewall ip address of snmp interface
                snmp_ip = ip_address_of_snmp_interface[0][0]
                firewall_dict = {f"Firewall_name": [f"{firewall_name}"],
                                 "IP": [f"{snmp_ip}"],
                                 "Interface": [f"{to_get_snmp_interface}"]}
                df_updated = pd.concat([existing_df, pd.DataFrame(firewall_dict)], ignore_index=True)
                df_updated.to_excel(existing_file, index=False, sheet_name='mySheet')
                print(firewall_dict)
            except:
                print(f"not able to get the detail of {firewall_name}")
################################### Update the firewall Database ###############################################
    def Update_fw_DB(self,existing_file,firewall_name):
        self.sigle_ngfw_name_and_IP(existing_file,firewall_name)

################################### Update the firewall Database ###############################################
    def refresh_fw_DB(self,existing_file):
        """
        This function will update the firewall data fetched from SMC, this function expect the firewall input raw file,
        file type expected to be .xlsx
        :param existing_file:
        :return:
        """
        def find_unique_firewall(smc_fw_list, db_fw_list):
            C = []  # List to store elements from A not present in B
            for element in smc_fw_list:
                if element not in db_fw_list:
                    C.append(element)
            return C
        smc_fw_list = self.get_all_ngfw_name()
        # print(smc_fw_list)
        file_path = existing_file
        df = pd.read_excel(file_path)
        db_fw_list = df['Firewall_name'].tolist()
        # print(db_fw_list)
        result_list = find_unique_firewall(smc_fw_list, db_fw_list)
        # print(result_list)
        for uniq_fw in result_list:
            self.sigle_ngfw_name_and_IP(existing_file,uniq_fw)

#======================== class test code ========================#.

"""
    This section will give the ngfw data
"""
class Fpngfw:
    def __init__(self):
        # self.FIREWALL_IP = "SureshS"
        self.FIREWALL_USERNAME = "SureshS"
        self.FIREWALL_PASSWORD = ""
    def fw_db_dict(self,existing_file):
        # file_path = 'your_file.xlsx'  # Read the Excel file
        df = pd.read_excel(existing_file)
        firewall_dict = {}  # Initialize an empty dictionary
        for index, row in df.iterrows(): # Iterate through each row in the DataFrame
            firewall_name = row['Firewall_name']
            ip = row['IP']
            firewall_dict[firewall_name] = ip # Add the key-value pair to the dictionary
        return firewall_dict

    def fw_db_renew(self,existing_file):
        fw_dict = self.fw_db_dict(existing_file)
        for fw in fw_dict:
            print(fw,"-->",fw_dict[fw])


        # # Print the resulting dictionary
        # print(firewall_dict)
        # # Print the IP for a specific Firewall_name
        # firewall_name_to_search = 'ngfw_name'  # Replace with the desired Firewall_name
        # if firewall_name_to_search in firewall_dict:
        #     print(f"IP for {firewall_name_to_search}: {firewall_dict[firewall_name_to_search]}")
        # else:
        #     print(f"Firewall_name {firewall_name_to_search} not found.")
        #
        # # Print Firewall_name and relevant IP using a for loop
        # for index, row in df.iterrows():
        #     print(f"Firewall_name: {row['Firewall_name']}, IP: {row['IP']}")

























