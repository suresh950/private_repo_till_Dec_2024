""" This is function will ssh to the single firewall and return the output
list of Forcepoint command user in the script
cmd = [f"echo {password} | sudo -S dmidecode | grep -A6 0x0003 | tail -1",
       f"echo {password} | sudo -S ip a",
       f"echo {password} | sudo -S sg-dmidata",
       f"echo {password} | sudo -S sg-version"]
"""
import time
import re
import paramiko
class SSH_ngfw:
    def __int__(self):
        pass
    def SSH_fw(self, ngfw_ip):
        """ This function will execute the code and will display the output on output screen """
        """ Creating ssh client instanciate """
        username = "SureshS"
        password = "Raginee@123456"
        commands = [f"echo {password} | sudo -S dmidecode | grep -A6 0x0003 | tail -1",
                       f"echo {password} | sudo -S sg-status -l",
                       f"echo {password} | sudo -S sg-dmidata",
                       f"echo {password} | sudo -S sg-version"]

        serial_number = re.compile(r'(Serial Number: )(.+)')
        product_name = re.compile(r'(Product Name: )(.+)')
        pol = re.compile(r'(STONE-ID: )(.+)')
        ver = re.compile(r'(NGFW version )(.+)')

        try:
            ssh_client = paramiko.client.SSHClient()
            ssh_client.set_missing_host_key_policy(paramiko.client.AutoAddPolicy())
            ssh_client.connect(hostname=ngfw_ip, username=username,
                               password=password, port=22,
                               look_for_keys=False,
                               allow_agent=False)
            print(f"Connecting to {ngfw_ip}")
            """ Sending the command to cisco device """
            connect = ssh_client.invoke_shell()
            for command in commands:
                connect.send(f"{command} \n".encode("utf-8"))
            time.sleep(5)
            output = connect.recv(9899)
            connect.close()
            fw_output = output.decode()

            output_serial_number = serial_number.search(string=fw_output)
            output_model = product_name.search(string=fw_output)
            output_pol = pol.search(string=fw_output)
            output_ver = ver.search(string=fw_output)

            fw_serial_number = output_serial_number.group(2)
            fw_model = output_model.group(2)
            fw_pol = output_pol.group(2)
            firmware_version = output_ver.group(2)
            print("fw_serial_number : ",fw_serial_number)
            print("fw_model: ",fw_model)
            print("firmware_version : ",firmware_version)
            print("fw_pol :",fw_pol)

        except:
            print(f"Unable to login to the Firewall")