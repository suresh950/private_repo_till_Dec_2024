""" This is function will ssh to the single firewall and return the output
list of Forcepoint command user in the script
cmd = [f"echo {password} | sudo -S dmidecode | grep -A6 0x0003 | tail -1",
       f"echo {password} | sudo -S ip a",
       f"echo {password} | sudo -S sg-dmidata",
       f"echo {password} | sudo -S sg-version"]
"""
import time
import re
from datetime import datetime
# from S_K_CLASS_OF_paramiko import *
from csv import DictReader
import csv
import pandas as pd
import paramiko
class SSH_ngfw:
    def __int__(self):
        existing_file = 'output_files/file.xlsx'
        sheet_name = 'mySheet'
    def Date_Time(self):
        """ this function will return date and time in string formate """
        name_a =f"{datetime.now()}".replace(":",".")
        return name_a.replace(" ","_")
    def SSH_fw(self, ngfw_ip):
        """ This function will execute the code and will display the output on output screen """
        """ Creating ssh client instanciate """
        username = "SureshS"
        password = "Raginee@123456"
        commands = [f"echo {password} | sudo -S dmidecode | grep -A6 0x0003 | tail -1",
                       f"echo {password} | sudo -S sg-status -l",
                       f"echo {password} | sudo -S sg-dmidata",
                       f"echo {password} | sudo -S sg-version"]
        try:
            ssh_client = paramiko.client.SSHClient()
            ssh_client.set_missing_host_key_policy(paramiko.client.AutoAddPolicy())
            ssh_client.connect(hostname=ngfw_ip, username=username,
                               password=password, port=22,
                               look_for_keys=False,
                               allow_agent=False)
            print(f"Connecting to {ngfw_ip}")
            """ Sending the command to cisco device """
            connect = ssh_client.invoke_shell()
            for command in commands:
                connect.send(f"{command} \n".encode("utf-8"))
            time.sleep(5)
            output = connect.recv(9899)
            connect.close()
            fw_output = output.decode()
            print(fw_output)
        except:
            print(f"Unable to login to the Firewall")