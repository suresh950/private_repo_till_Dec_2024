"""
this Will update the raw data of the firewall database
which will be used in SSH_connect_ngfw module (SSH_connect_ngfw is custom module)

"""
from CMDB_SMC import *

existing_file = "output_files/New_file1.xlsx"
update = CustomSmcClass()
update.connect_to_smc()
update.refresh_fw_DB(existing_file)
update.close_connection()