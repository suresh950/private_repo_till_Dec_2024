from nmap3 import *

initial_nmap = Nmap()
target = "100.64.99.99"
output = initial_nmap.scan_command(target=target,arg="-sS")
for key in output:
    print(f"{key}")