from nmap3 import Nmap
import xml.etree.ElementTree as ET

initial_nmap = Nmap()
target = "172.16.98.20"
output = initial_nmap.scan_command(target=target, arg="-Pn -sU -p44818")

# Iterate through the XML elements and print their content
for element in ET.ElementTree(output).iter():
    # Convert the Element object to a string
    element_string = ET.tostring(element, encoding='unicode')
    with open("raw_data.xml","a") as ra:
        ra.write(element_string)