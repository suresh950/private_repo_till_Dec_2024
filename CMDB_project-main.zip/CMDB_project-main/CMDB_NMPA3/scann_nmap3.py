import nmap3
from pprint import pprint
# Create an nmap3 object
nm = nmap3.Nmap()

# Specify the target host or IP address
target = '10.63.2.212'

# Perform an OS detection scan
result = nm.nmap_os_detection(target)

pprint(result)
# Check if 'osclass' key exists in the result
# if target in result and 'osclass' in result[target]:
#     for os_info in result[target]['osclass']:
#         print(f"OS Type: {os_info['osfamily']} - {os_info['osgen']} - {os_info['osaccuracy']}%")
# else:
#     print(f"OS information not available for {target}.")


