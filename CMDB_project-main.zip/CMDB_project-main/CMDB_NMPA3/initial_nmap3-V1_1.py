from nmap3 import Nmap
import xml.etree.ElementTree as ET
from pprint import pprint
initial_nmap = Nmap()
target = "100.64.99.99"
output = initial_nmap.scan_command(target=target, arg="-sS")

# Iterate through the XML elements and print their content
for element in ET.ElementTree(output).iter():
    # Convert the Element object to a string
    element_string = ET.tostring(element, encoding='unicode')
    pprint(element_string)