"""
    This script will give the SNMP interface ip.
"""
# Importing SMC required library and CSV library
import smc
import csv
from smc.core.engines import Engine
from smc.core.engines import Layer3Firewall
import os
import datetime
date_time_now = datetime.datetime.now().strftime('%Y-%m-%d %H-%M-%S')
new_file_name = f"ngfw_and_its_snmp_ip.csv"
with open(f"{new_file_name}",mode="w") as new_csv_file:
    inital_row = ["firewall-Name", "SNMP-IP", "Interface"]
    to_csv_created_file = csv.writer(new_csv_file)
    to_csv_created_file.writerow(inital_row)

SMC_API_URL = os.environ["SMC_API_URL"]
# My API Key
API_KEY = os.environ["SMC_READ_API_KEY"]

# Connecting the firewall
def connect_to_smc():
    smc.session.login(url=SMC_API_URL, api_key=API_KEY)
connect_to_smc()

# reading the firewall name from "firewall.csv"
engine = Engine.objects.all()
# looping in the Engine all objects
n = 0
for node in engine:
    n+=1
    each_node = node.nodes
    firewall_name = node.name
    # exception handling
    try:
        # getting into firewall
        into_firewall = Layer3Firewall.get(name=f"{firewall_name}")
        # Getting firewall interface name
        to_get_snmp_interface = into_firewall.snmp.interface[0].name
        # Getting firewall interface id
        snmp_interface_id = to_get_snmp_interface.split()[1]
        # Getting firewall ip address of snmp interface
        ip_address_of_snmp_interface = into_firewall.interface.get(interface_id=snmp_interface_id).addresses
        snmp_ip = ip_address_of_snmp_interface[0][0]
        # Creating a list of details
        new_row =[firewall_name,snmp_ip,to_get_snmp_interface]
        # adding a row in "firewall_and_its_snmp_ip.csv" file using list
        with open(f"{new_file_name}","a",newline='') as firewall_and_its_snmp_ip:
            to_csv = csv.writer(firewall_and_its_snmp_ip)
            to_csv.writerow(new_row)
        # n is the number tested firewall
        print(n)
    except:
        # if above code fails then this will execute
        # or "may be the firewall name is wrong or firewall not present in SMC"
        print(f"not able to get the detail of {firewall_name}")
    n+=1
# Closing the connection.
smc.session.logout()