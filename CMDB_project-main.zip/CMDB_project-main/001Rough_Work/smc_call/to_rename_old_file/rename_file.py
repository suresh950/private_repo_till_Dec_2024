import os

def rename_file(old_name, new_name):
    try:
        os.rename(old_name, new_name)
        print(f"File '{old_name}' successfully renamed to '{new_name}'.")
    except FileNotFoundError:
        print(f"Error: File '{old_name}' not found.")
    except PermissionError:
        print(f"Error: Permission denied to rename '{old_name}' to '{new_name}'.")
    except Exception as e:
        print(f"An error occurred: {e}")

# Example usage:
old_filename = 'old_file.txt'
new_filename = 'new_file.txt'

rename_file(old_filename, new_filename)
