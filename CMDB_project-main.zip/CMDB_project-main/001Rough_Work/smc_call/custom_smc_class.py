import csv
import os
import time
import smc
from smc.core.engines import Engine
import pandas as pd
class CustomSmcClass:
    def __init__(self):
        self.SMC_API_URL = os.environ["SMC_API_URL"]
        # self.API_KEY ="r7ej5VyhVorLzkss4Sfg6Lgd"
        self.API_KEY = os.environ["SMC_READ_API_KEY"]

##################################################################################
    def connect_to_smc(self):
        """Establishing connection to SMC"""
        smc.session.login(url=self.SMC_API_URL, api_key=self.API_KEY)

##################################################################################
    def close_connection(self):
        """Closing the connection to SMC"""
        smc.session.logout()
##################################################################################
    def one_node_status(self,ngfw:str):
        """ Getting the one ngfw Engine health status
         ( please enter the firewall name as string )"""
        engine1 = Engine.get(ngfw)
        for node_status in engine1.nodes:
            # Getting the one ngfw Engine helth status
            firewall_status = node_status.health.engine_node_status
            print(firewall_status)
##################################################################################
    def get_all_ngfw_name(self,ngfw_file):
        """ This function will give the all firewall name available in SMC
        ( provide the file name to store the data )"""
        # getting into SMC
        engine = Engine.objects.all()
        # looping in the Engine all objects
        for node in engine:
            # taking down the name from the node
            print(node.name)
            # creating list of firewall name
            new_row = [node.name]
            # creating one csv file and adding row with help of list
            with open(ngfw_file, "a", newline='') as firewall_name:
                to_csv = csv.writer(firewall_name)
                to_csv.writerow(new_row)
##################################################################################
    def refresh_ngfw(self,ngfw_file,ngfw_error):
        """This function will get the firewall name from csv file and
        it will refresh the firewall
        ( provide the firewall file (or firewall file path) in csv and error file )"""
        with open(ngfw_file, mode='r') as file:
            # reading the CSV file
            csvFile = csv.reader(file)
            for lines in csvFile:
                firewall_name_to_refresh = lines[0]
                try:
                    engine = Engine(f'{firewall_name_to_refresh}')
                    engine.refresh()
                    print(f"Firewall is refreshing FW Name : {firewall_name_to_refresh}...........")
                    time.sleep(90)
                except:
                    print(f"Error refreshing the firewall @@@@@@@@@ {firewall_name_to_refresh} @@@@@@@@")
                    with open(ngfw_error, "a", newline='') as errorfw:
                        to_csv = csv.writer(errorfw)
                        new_row = [firewall_name_to_refresh]
                        to_csv.writerow(new_row)
##################################################################################
    def ngfw_details(self,output_file):
        """ this function will provide the all the ngfw name and ngfw status and interface ip
        ( Provide file name to store the output )"""
        # getting into SMC
        engine = Engine.objects.all()
        # looping in the Engine all objects
        n = 0
        for node in engine:
            n += 1
            each_node = node.nodes
            for each_name in each_node:
                new_name = each_name.name
                ngfw_status = each_name.health.engine_node_status
                print(n, " ", new_name, f"------------->", ngfw_status)
                # creating list of firewall name and firewall status
                new_row = [new_name, ngfw_status]
                # creating one csv file and adding row with help of list
                with open(output_file, "a", newline='') as firewall_name:
                    to_csv = csv.writer(firewall_name)
                    to_csv.writerow(new_row)
##################################################################################

    def Disabled_Rules_ALL_RO_FW(self,File_Path,ngfw_name_str):
        """ this function will provide the all the ngfw access policy and nat policy details
                ( Provide file name to store the output )"""
        # temp = 0
        # Excel Writer
        writer = pd.ExcelWriter(File_Path, engine='xlsxwriter')
        r = 0
        s = 0
        d = 0
        k = 0
        n = 0
        for Engine1 in Engine.objects.all():
            try:
                FW_Name = Engine1.name
                filter = ngfw_name_str
                #to match last characters
                # leng1 = len(filter)
                # last_fw = FW_Name[-leng1:]
                # if last_fw == filter:
                # to match exact firewall
                # filter1 = "KWT-DC-OOREDOO-R01-FW"
                # if FW_Name == filter1:

                # to look for string in firewall
                if (filter in FW_Name) == True:
                    print(Engine1.name)
                    # temp = temp +1
                    # if temp == 5:
                    #     break
                    lst2 = []
                    lst3 = []
                    lst4 = []
                    lst5 = []
                    lst6 = []
                    lst7 = []
                    lst8 = []
                    lst9 = []
                    lst10 = []
                    lst11 = []
                    lst12 = []
                    lst13 = []
                    lst14 = []
                    policy_dup = Engine1.installed_policy
                    policy = FirewallPolicy.get(policy_dup)
                    for rule in policy.fw_ipv4_access_rules:
                        try:
                            k = k + 1
                            if rule.is_disabled:
                                print("Disabled Rule", rule.name)
                                r = r + 1
                                pass
                            elif (rule.sources.all() is None) & (rule.destinations.all() is None):
                                print("No Source or Destinations")
                                s = s + 1
                                pass
                            else:
                                d = d + 1
                                lst2.append(Engine1.name)
                                df2 = pd.DataFrame({'Firewall_Name': (lst2)})
                                # print(df2)

                                lst3.append(policy_dup)
                                df3 = pd.DataFrame({'Policy_Name': (lst3)})

                                rule1 = rule
                                lst5.append(rule1)
                                df5 = pd.DataFrame({'RULE': (lst5)})

                                ruletype = rule.typeof
                                lst6.append(ruletype)
                                df6 = pd.DataFrame({'RULE_TYPE': (lst6)})

                                rulename = rule.name
                                lst7.append(rulename)
                                df7 = pd.DataFrame({'RULE_Name': (lst7)})

                                rulesource = rule.sources.all()
                                lst8.append(rulesource)
                                df8 = pd.DataFrame({'Source': (lst8)})

                                ruledestination = rule.destinations.all()
                                lst9.append(ruledestination)
                                df9 = pd.DataFrame({'Destination': (lst9)})

                                ruledestination = rule.services.all()
                                lst10.append(ruledestination)
                                df10 = pd.DataFrame({'Services': (lst10)})

                                if rule.action:
                                    ruleaction = rule.action.action
                                    lst11.append(ruleaction)
                                    df11 = pd.DataFrame({'Action': (lst11)})
                                else:
                                    ruleaction = "None"
                                    lst11.append(ruleaction)
                                    df11 = pd.DataFrame({'Action': (lst11)})

                                rulecomment = rule.comment
                                lst12.append(rulecomment)
                                df12 = pd.DataFrame({'Comment': (lst12)})

                                df2.to_excel(writer, FW_Name, index=False, startcol=0)
                                df3.to_excel(writer, FW_Name, index=False, startcol=1)
                                df5.to_excel(writer, FW_Name, index=False, startcol=2)
                                df6.to_excel(writer, FW_Name, index=False, startcol=3)
                                df7.to_excel(writer, FW_Name, index=False, startcol=4)
                                df8.to_excel(writer, FW_Name, index=False, startcol=5)
                                df9.to_excel(writer, FW_Name, index=False, startcol=6)
                                df10.to_excel(writer, FW_Name, index=False, startcol=7)
                                df11.to_excel(writer, FW_Name, index=False, startcol=8)
                                df12.to_excel(writer, FW_Name, index=False, startcol=9)
                        except TypeError as e:
                            # print(rule.sources)
                            n = n+1
                            pass
                    print("TOTAL RULES :", k, "DISABLED RULES: ", r, " NO Source or Destinations : ", s, "PROBLEM RULES",d,"TYPE ERROR",n)
            except Exception as e:
                # print("error occured",FW_Name)
                print(e)
                pass
                # break

        writer.close()