import time
from datetime import datetime
from csv import DictReader
import csv
import paramiko
class CiscoParamiko():
    def __int__(self):
        pass
    def Date_Time(self):
        """ this function will return date and time in string formate """
        name_a =f"{datetime.now()}".replace(":",".")
        return name_a.replace(" ","_")
    def config_command_executor(self, hostname, commands, user, passw):
        """ this function will execute the code and will display the output on output screen
        hostname = device ip address,
        commands = list of commands,
        user = Username ,
        passw = Password,
        """
        """ Creating ssh client instanciate """
        try:
            ssh_client = paramiko.client.SSHClient()
            ssh_client.set_missing_host_key_policy(paramiko.client.AutoAddPolicy())
            ssh_client.connect(hostname=hostname, username=user,
                               password=passw, port=22,
                               look_for_keys=False,
                               allow_agent=False)
            print(f"Connecting to {hostname}")
            """ Sending the command to cisco device """
            connect = ssh_client.invoke_shell()
            for command in commands:
                connect.send(f"{command} \n".encode("utf-8"))
            time.sleep(5)
            output = connect.recv(9899)
            print(output.decode())
            connect.close()
        except:
            print(f"Opps Somthing Went Wrong")

connect_ssh = CiscoParamiko()
connect_ssh.config_command_executor("10.209.9.113", ["dmidecode | grep -A6 0x0003 | tail -1"], "root", "3s)5437BQN_#bHL")