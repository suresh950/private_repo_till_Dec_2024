"""
This is script will give the SN number of the firewall
"""
from CMDB_SMC_class import *
import time
from datetime import datetime
import paramiko
class NgfwParamiko():
    def __int__(self):
        pass
    def Date_Time(self):
        """ this function will return date and time in string formate """
        name_a =f"{datetime.now()}".replace(":",".")
        return name_a.replace(" ","_")
    def config_command_executor(self, hostname, commands, user, passw):
        """ this function will execute the code and will display the output on output screen
        hostname = device ip address,
        commands = list of commands,
        user = Username ,
        passw = Password,
        """
        """ Creating ssh client instanciate """
        try:
            ssh_client = paramiko.client.SSHClient()
            ssh_client.set_missing_host_key_policy(paramiko.client.AutoAddPolicy())
            ssh_client.connect(hostname=hostname, username=user,
                               password=passw, port=22,
                               look_for_keys=False,
                               allow_agent=False)
            print(f"Connecting to {hostname}")
            """ Sending the command to cisco device """
            connect = ssh_client.invoke_shell()
            for command in commands:
                connect.send(f"{command} \n".encode("utf-8"))
            time.sleep(5)
            output = connect.recv(9899)
            return output.decode()
            connect.close()
        except:
            print(f"Opps Somthing Went Wrong")

connect_ssh = NgfwParamiko()
output = connect_ssh.config_command_executor("10.209.9.113", ["echo Raginee@123456 | sudo -S dmidecode | grep -A6 0x0003 | tail -1"], "SureshS", "Raginee@123456")

print(output)