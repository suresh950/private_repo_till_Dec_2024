"""
This is script will give the SN number of the firewall
Note :- this will prompt for firewall IP
"""
import time
from datetime import datetime
import paramiko
class NgfwParamiko():
    def __int__(self):
        pass
    def Date_Time(self):
        """ this function will return date and time in string formate """
        name_a =f"{datetime.now()}".replace(":",".")
        return name_a.replace(" ","_")
    def config_command_executor(self, hostname, commands, user, passw):
        """ this function will execute the code and will display the output on output screen
        hostname = device ip address,
        commands = list of commands,
        user = Username ,
        passw = Password,
        """
        """ Creating ssh client instanciate """
        try:
            ssh_client = paramiko.client.SSHClient()
            ssh_client.set_missing_host_key_policy(paramiko.client.AutoAddPolicy())
            ssh_client.connect(hostname=hostname, username=user,
                               password=passw, port=22,
                               look_for_keys=False,
                               allow_agent=False)
            print(f"Connecting to {hostname}")
            """ Sending the command to cisco device """
            connect = ssh_client.invoke_shell()
            for command in commands:
                connect.send(f"{command} \n".encode("utf-8"))
            time.sleep(5)
            output = connect.recv(9899)
            print(output.decode())
            connect.close()
        except:
            print(f"Opps Somthing Went Wrong")
ngfw_ip = input("Enter the firewall IP : ")
connect_ssh = NgfwParamiko()
connect_ssh.config_command_executor(ngfw_ip, ["dmidecode | grep -A6 0x0003 | tail -1"], "root", "3s)5437BQN_#bHL")