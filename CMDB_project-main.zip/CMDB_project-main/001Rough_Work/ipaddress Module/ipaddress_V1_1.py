import ipaddress
def print_network_info(network_segment):
    try:
        network = ipaddress.IPv4Network(network_segment, strict=False)

        print(f"Address:   {str(network.network_address)}")
        print(f"Netmask:   {network.netmask} = {network.prefixlen}")
        print(f"Wildcard:  {network.hostmask}\n")

        print(f"Network:   {network}")
        print(f"Broadcast: {network.broadcast_address}")
        print(f"HostMin:   {network.network_address + 1}")
        print(f"HostMax:   {network.network_address + network.num_addresses - 2}")
        print(f"Hosts/Net: {network.num_addresses - 2}")
    except ValueError as e:
        print(f"Error: {e}")


network_segment = input("Enter network segment (e.g., 192.168.1.0/24): ")
print_network_info(network_segment)
