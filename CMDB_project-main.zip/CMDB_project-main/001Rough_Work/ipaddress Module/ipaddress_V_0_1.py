"""
this code prompts for network segment, and it gives all usable IP available in the segment
"""
import ipaddress
def print_ips_in_segment(network_segment):
    try:
        network = ipaddress.IPv4Network(network_segment, strict=False)
        for ip in network.hosts():
            print(str(ip))
    except ValueError as e:
        print(f"Error: {e}")
# Example usage:

network_segment = "10.29.26.0/26"#input("Enter network segment (e.g., 192.168.1.0/24): ")
print_ips_in_segment(network_segment)