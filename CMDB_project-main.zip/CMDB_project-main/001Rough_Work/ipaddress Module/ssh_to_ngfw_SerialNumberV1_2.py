"""
This is script will give the SN number of the firewall
Note :- this will prompt for firewall IP
"""
from CMDB_SMC_class import *
ngfw_ip = "10.209.9.113"
username = "SureshS"
password = "Raginee@123456"
commands = [f"echo {password} | sudo -S dmidecode | grep -A6 0x0003 | tail -1",
            f"echo {password} | sudo -S dmidecode -s system-product-name"]
connect_ssh = NgfwParamiko()
output = connect_ssh.config_command_executor(ngfw_ip, commands, username, password)
print(output)