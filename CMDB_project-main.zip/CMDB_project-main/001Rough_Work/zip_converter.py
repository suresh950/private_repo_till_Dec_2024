import zipfile
import os

def zip_files(file_paths, zip_name):
    with zipfile.ZipFile(zip_name, 'w') as zip_file:
        for file_path in file_paths:
            # Add each file to the zip file
            zip_file.write(file_path, os.path.basename(file_path))

# List of file paths to be zipped
files_to_zip = ['C:/Users/Suresh Kushwaha/Downloads/ELSS investment.pdf',
                'C:/Users/Suresh Kushwaha/Downloads/rental_agrement.pdf',
                'C:/Users/Suresh Kushwaha/Downloads/Rental_recipt (1).pdf']

# Name of the zip file to be created
zip_file_name = 'Investment-Documents.zip'

# Call the function to zip the files
zip_files(files_to_zip, zip_file_name)

print(f'The files {files_to_zip} have been zipped into {zip_file_name}')
