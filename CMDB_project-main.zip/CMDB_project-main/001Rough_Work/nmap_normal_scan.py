import nmap

scanner = nmap.PortScanner()
# remote_host = "10.29.26.31"
remote_host = "172.16.200.130"
scann_out = scanner.scan(remote_host,'0-1024',arguments='-o')
# print(scanner.scaninfo())
print(scann_out)