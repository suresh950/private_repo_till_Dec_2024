import nmap


def scan_and_get_mac(remote_host, ports):
    try:
        # Initialize the scanner
        scanner = nmap.PortScanner()

        # Convert the list of ports to a string
        ports_str = ','.join(map(str, ports))

        # Perform a full scan with aggressive options
        scan_out = scanner.scan(remote_host, ports=ports_str, arguments='-Pn -sS -sV -sC -A -O')

        # Check if the host is up and responding to the scan
        if remote_host in scan_out["scan"] and "addresses" in scan_out["scan"][remote_host]:
            addresses = scan_out["scan"][remote_host]["addresses"]

            # Check if MAC address is available
            if "mac" in addresses:
                mac_address = addresses["mac"]
                print(f"MAC Address of {remote_host}: {mac_address}")
            else:
                print(f"No MAC Address found for {remote_host}")

            # Print other scan information
            print("\nNmap Scan Information:")
            print(scan_out["nmap"])

        else:
            print(f"The host {remote_host} is not responding to the scan.")

    except nmap.PortScannerError as e:
        print(f"Nmap scan error: {e}")

    except Exception as e:
        print(f"An unexpected error occurred: {e}")


# Example usage with a list of ports
remote_host_to_scan = "172.16.200.130"
ports_to_scan = [80, 443, 8080]
scan_and_get_mac(remote_host_to_scan, ports_to_scan)
