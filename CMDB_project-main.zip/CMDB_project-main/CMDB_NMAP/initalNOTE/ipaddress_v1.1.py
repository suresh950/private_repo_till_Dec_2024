import ipaddress

def print_ip_addresses(ip_segment):
    network = ipaddress.IPv4Network(ip_segment, strict=False)
    for ip_address in network:
        ipadr = str(ip_address)
        print(ipadr)

# Example usage
# ip_segment = "192.168.1.0/30" # Replace this with your desired IP segment
ip_segment = input("Please provide the IP segment : ")
print_ip_addresses(ip_segment)