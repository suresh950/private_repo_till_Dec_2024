"""
this script will show the device status whether it is up or down (or ip is reachable or not)
"""
# importing the nmap module
import nmap
# Calling PortScanner() class from nmap module
scanner = nmap.PortScanner()
# hard coding the host ip to check the status
ip_list = ["194.176.108.1",
            "94.246.14.1",
            "168.187.252.129",
            "195.39.130.161",
            "168.187.79.1",
            "62.215.33.65",
            "168.187.36.192"]

# ip_addr = "100.64.99.99"
# initiating the scan it has host = ip_addr, ports = range of port you want to scan, arguments = this is command to scan
# i have not given the port range to scan because i am just checking the host status
for ip_addr in ip_list:
    scanner.scan(hosts=ip_addr,ports="0",arguments='-v -sS -sV -sC -A -O')
    # getting the host status
    print(f"Host Status: {ip_addr} ",scanner[ip_addr].state())
