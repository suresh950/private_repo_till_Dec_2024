import nmap

scanner = nmap.PortScanner()

ip_addr = "100.64.99.99"

scanner.scan(ip_addr,'1-1024',arguments='-v -sS -sV -sC -A -O')
print(scanner.scaninfo())
print("Scanner Status: ",scanner[ip_addr].state())
print(scanner[ip_addr].all_protocols())
print("Open Ports: ",scanner[ip_addr]['tcp'].keys())