import nmap3
nmap_cust = nmap3.Nmap()
result = nmap_cust.nmap_version_detection("google.com")
