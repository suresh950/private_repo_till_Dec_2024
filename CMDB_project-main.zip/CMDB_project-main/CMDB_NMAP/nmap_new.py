import asyncio
# from python3_nmap import NmapScanTechniquesAsync
from nmap3 import *
async def check_host_up(target):
    nmap_cust = NmapScanTechniquesAsync()
    await nmap_cust.nmap_version()
    
    # Perform a ping scan (no port scan)
    result = await nmap_cust.scan_command(target=target, scan_type=4, args="-sn")
    
    # Check if the host is up based on the Nmap output
    print(result)
    host_up = '1 host up' in result
    if host_up:
        print(f"The host {target} is up.")
    else:
        print(f"The host {target} is down.")

# Replace 'your_target_ip' with the IP address or hostname you want to check
target_ip = '100.64.99.55'

# Create an event loop and run the asynchronous function
asyncio.run(check_host_up(target_ip))
