"""
this script will show the device status whether it is up or down (or ip is reachable or not)
"""
# importing the nmap module
import nmap
# Calling PortScanner() class from nmap module
scanner = nmap.PortScanner()
# hard coding the host ip to check the status
ip_addr = "172.16.98.20"
# initiating the scan it has host = ip_addr, ports = range of port you want to scan, arguments = this is command to scan
# i have not given the port range to scan because i am just checking the host status
scanner.scan(hosts=ip_addr,ports="0",arguments='-v -sS -sV -sC -A -O')
# getting the host status
print(f"Host Status: {ip_addr} ",scanner[ip_addr].state())
