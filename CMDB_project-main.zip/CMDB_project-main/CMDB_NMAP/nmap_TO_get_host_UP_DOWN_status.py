"""
this script will show the device status whether it is up or down (or ip is reachable or not)
"""
# importing the nmap module
import nmap
# calling PortScanner() class from nmap module
scanner = nmap.PortScanner()
# hard coding the host ip to check the status
ip_addr = "10.41.250.10"
# print(type(ip_addr))
# print("nmap version: ",scanner.nmap_version())
# initiating the scan it has host = ip_addr, ports = range of port you want to scan, arguments = this is command to scan
scanner.scan(hosts=ip_addr,ports='1-1024',arguments='-v -sS -sV -sC -A -O')
# print(scanner.scaninfo())
# getting the host status
print("Scanner Status: ",scanner[ip_addr].state())
# print(scanner[ip_addr].all_protocols())
# print("Open Ports: ",scanner[ip_addr]['tcp'].keys())