"""
this code will write the data in xlsx sheet
* This is code is using SSH_connect_ngfw module (the custom module )
"""
import concurrent.futures
from SSH_connect_ngfw import *
"""
connecting to firewall 
"""
existing_file_OUTPUT = "output_files/ngfw_data.xlsx"
connect_to_firewall = SSH_ngfw()
# Example firewall to test the SSH_connect_ngfw module.
input_file_path = "output_files/New_file1.xlsx"
input_fw_file_path = existing_file_OUTPUT
# df = pd.read_excel(input_file_path) # dataframe from SMC DB
df2 = pd.read_excel(input_fw_file_path) # dataframe from firewall DB

df10 = pd.read_excel(input_file_path) # dataframe from SMC DB
df20 = pd.read_excel(input_file_path, usecols=["Node2_IP"])
Node1_IP_fw_list = df10['Node1_IP'].tolist()
Node2_IP_fw_list = df20["Node2_IP"].dropna().tolist()
smc_db_fw_list = Node1_IP_fw_list + Node2_IP_fw_list
db_fw_list = df2['LAN_IP'].tolist()


def find_unique_fw_ip(smc_db_fw_list, db_fw_list):
    C = []  # List to store elements from A not present in B
    for element in smc_db_fw_list:
        if element not in db_fw_list:
            C.append(element)
    return C
# df = pd.read_excel(input_file_path)
db_fw_ip_list = find_unique_fw_ip(smc_db_fw_list=smc_db_fw_list,db_fw_list=db_fw_list)
# ip_list = ["10.144.3.101", "10.173.98.161", "10.21.51.225","10.175.171.10","10.144.3.165"]
# for ip in db_fw_ip_list:
#     connect_to_firewall.SSH_fw(ip)
with concurrent.futures.ThreadPoolExecutor() as executor:
    futures = []
    for ip in db_fw_ip_list:
        executor.submit(connect_to_firewall.SSH_fw, ip)
        # futures.append(future)
# result_dict_list = [future.result() for future in futures]
# for result_dict in result_dict_list:
#     existing_df = pd.read_excel(existing_file_OUTPUT, sheet_name="ngfw-data")
#     df_updated = pd.concat([existing_df, pd.DataFrame(result_dict)], ignore_index=True)
#     df_updated.to_excel(existing_file_OUTPUT, index=False, sheet_name='ngfw-data')
#     print(result_dict)
